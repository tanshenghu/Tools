$(function(){
	
	$('#frm1').validate({ 
		//校验规则
		rules: {
			phone: {
				required : true,
				phone : true
			},
			email: {
				required : true,
				email : true
			},
			password: {
				required : true,
				minlength : 6
			},
			confirm_password: {
				equalTo: "#password"
			}
		},
		//错误提示信息
		messages: {
			phone: {
				required : '请输入手机号码',
				phone : '请填写正确的手机号码'
			},
			email: {
				required : '邮箱不能为空',
				email : '邮箱格式有误'
			},
			password: {
				required : '密码不能为空',
				minlength : '密码长度不能少于6位'
			},
			confirm_password: {
				
				equalTo: "两次输入的密码不一致"
			}
		},submitHandler:function(form){
            alert("准备提交后台");   
            //form.submit();
        }
	});
	

	//失焦校验
	$('.J-lose_focus').blur(function(){
		$('#frm1').validate();
	})
	
});

$(function(){
	
	$('.select').click(function(){
		$(this).find('ul').stop().show();

		$(this).find('li').click(function(){
			$(this).parent().parent().find('span').html($(this).text());
			$(this).parent().hide();
			return false;
		})
		return false;
		
	})
	$(document).click(function(){
		$('.select ul').hide();

	})

	
})