<?php
	header("content-type:application/json; charset=UTF-8");
	echo '{"returnValue":{"count":5,"list":[
	{"name":"张三丰","shopname":"淘宝店铺","phone":"14512345678","qq":"511568690","classname":"家纺类","status":0},
	{"name":"张无忌","shopname":"天猫店铺","phone":"13512345678","qq":"511568691","classname":"家纺类","status":1},
	{"name":"张翠山","shopname":"拍拍店铺","phone":"13612345678","qq":"511568692","classname":"家纺类","status":2},
	{"name":"李四","shopname":"京东店铺","phone":"13514535678","qq":"511568693","classname":"家纺类","status":3},
	{"name":"王五","shopname":"当当店铺","phone":"17892345678","qq":"511568694","classname":"家纺类","status":4}
	]},"hasError":false}';
?>