var _DYQ = {};

_DYQ.banner = function( box ){
	
	box = $( box );
	var ul = box.find('ul'),
		li = ul.find('li'),
		liw= box.width(),
		len= li.length;
	
	var step = 3000;
	
	ul.width( len * liw );
	li.height( box.height() ).width( liw );
	
	box.index = 1;
	
	var ahand = '';
	for(var i=1; i<=len; i++){
		ahand+='<a href="javascript:;" class="'+(i==1?"current":"")+'">'+i+'</a>';
	}
	var bannerhand = $('<div class="banner-hand">'+ahand+'</div>');
	box.append( bannerhand );
	
	var scrollfn = function( idx ){
		box.index = idx>-1 ? idx : box.index;

		var index = (box.index % len),
			left = index * liw;
		ul.animate({'margin-left':'-'+left+'px'}, 500);
		box.find('.banner-hand a').eq( index ).addClass('current').siblings('a').removeClass('current');
		
		box.index += 1;
	};
	var tm = setInterval(function(){
		scrollfn();
	}, step);
	
	box.find('.banner-hand a').on('mouseover', function(){
		if ( tm ){
			clearInterval( tm );
		}
		
		var index = $(this).index();
		scrollfn( index );
	}).on('mouseout', function(){
		
		tm = setInterval(function(){
			scrollfn();
		}, step);
		
	});
	
};

_DYQ.topUser = function(){
	
	var tid = null;
	
	$('#topBar li').hover(function(){
		clearTimeout( tid );
		$(this).addClass('active').siblings('li').removeClass('active');
	},function(){
		var thisObj = $( this );
		tid = setTimeout(function(){
			thisObj.removeClass('active');
		}, 200);
	});
	
	
};

// 首页 家用电器 商品切换
_DYQ.checkProduct = function(){
	
	$('.household .topbox li').on('mouseover', function(){
		var thisObj = $(this), idx = thisObj.index(),
			ol      = thisObj.closest('.check-list').find('.checkpro ol');
			
			thisObj.addClass('current').siblings().removeClass('current');
			ol.eq( idx ).show().siblings('ol').hide();
		
	});
	
	
};


$(function(){
	
	// banner
	_DYQ.banner('.banner');
	// 顶部 弹出下拉框
	_DYQ.topUser();
	// 首页 家用电器切换
	_DYQ.checkProduct();
	// banner下方滚动
	$(".scrollbox .scinfo").jCarouselLite({
		btnPrev: ".preBtn",
		btnNext: ".nextBtn",
		auto: 2500,
		scroll: 1,
		speed: 500,
		vertical: false,
		visible: 3,
		circular: true
	});
	
});