<?php include('public/head.php');?>
<body>
	<div class="wrap">
		<?php include('public/top.php');?>
		<!-- End userState -->
		<div class="leftBgColor"></div>
		<div id="content">
			<?php include('public/left.php');?>
			<!-- End leftMenu -->
			<div class="mainbox">
				<div class="webAdrs">
					<a href="#">首页</a> / <a href="#">二级菜单</a> / <span>三级菜单</span>
				</div>
				<h1>会员管理</h1>
				<div class="boxblock searchshoplist">
					<div class="titleBox">查看订单</div>
					<table class="grid">
						<thead>
							<tr>
								<th width="70">订单号</th>
								<th width="110">订单日期</th>
								<th>商品名称及缩略图</th>
								<th width="100">价格</th>
								<th width="110">数量</th>
								<th width="85">金额</th>
								<th width="85">状态</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>011111</td>
								<td>2014-11-11</td>
								<td><div class="picbox"><img src="static/images/pic.jpg"><span>远梦床上四件套</span></div></td>
								<td>&yen;999.00</td>
								<td>9999</td>
								<td>&yen;999.00</td>
								<td><span class="list-status1">上架</span></td>
							</tr>
							<tr>
								<td>011111</td>
								<td>2014-11-11</td>
								<td><div class="picbox"><img src="static/images/pic.jpg"><span>远梦床上四件套</span></div></td>
								<td>&yen;999.00</td>
								<td>9999</td>
								<td>&yen;999.00</td>
								<td><span class="list-status2">下架</span></td>
							</tr>
							<tr>
								<td>011111</td>
								<td>2014-11-11</td>
								<td><div class="picbox"><img src="static/images/pic.jpg"><span>远梦床上四件套</span></div></td>
								<td>&yen;999.00</td>
								<td>9999</td>
								<td>&yen;999.00</td>
								<td><span class="list-status1">上架</span></td>
							</tr>
							<tr>
								<td>011111</td>
								<td>2014-11-11</td>
								<td><div class="picbox"><img src="static/images/pic.jpg"><span>远梦床上四件套</span></div></td>
								<td>&yen;999.00</td>
								<td>9999</td>
								<td>&yen;999.00</td>
								<td><span class="list-status1">上架</span></td>
							</tr>
							<tr>
								<td>011111</td>
								<td>2014-11-11</td>
								<td><div class="picbox"><img src="static/images/pic.jpg"><span>远梦床上四件套</span></div></td>
								<td>&yen;999.00</td>
								<td>9999</td>
								<td>&yen;999.00</td>
								<td><span class="list-status1">上架</span></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			<!-- End mainBox -->
		</div>
		<!-- End content -->
	</div>
</body>
</html>