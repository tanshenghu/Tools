<?php include('public/head.php');?>
<body>
	<div class="wrap">
		<?php include('public/top.php');?>
		<!-- End userState -->
		<div class="leftBgColor"></div>
		<div id="content">
			<?php include('public/left.php');?>
			<!-- End leftMenu -->
			<div class="mainbox">
				<div class="webAdrs">
					<a href="#">首页</a> / <a href="#">二级菜单</a> / <span>三级菜单</span>
				</div>
				<h1>绑定银行账户</h1>
				<div class="boxblock searchshoplist">
					<div class="titleBox">账户列表<a href="javascript:;" class="addnew newBankBtn">新增账户</a></div>
					<table class="grid">
						<thead>
							<tr>
								<th width="250">开户行</th>
								<th>开户名</th>
								<th>账号</th>
								<th>是否默认</th>
								<th>是否第三方支付账号</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>中国农业银行</td>
								<td>XXX公司</td>
								<td>6234949494949</td>
								<td>是</td>
								<td>否</td>
							</tr>
							<tr>
								<td>中国农业银行</td>
								<td>XXX公司</td>
								<td>6234949494949</td>
								<td>是</td>
								<td>否</td>
							</tr>
							<tr>
								<td>中国农业银行</td>
								<td>XXX公司</td>
								<td>6234949494949</td>
								<td>是</td>
								<td>否</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			<!-- End mainBox -->
		</div>
		<!-- End content -->
	</div>
	<!-- 弹出层 -->
	<div class="popBox addNewBankPop">
		<div class="titleBox">新增账户<span class="closeMe" title="关闭"></span></div>
		<div class="popCon">
			<div class="formfield kd">
				<label class="label">开户行</label>
				<select>
					<option>中国工商银行</option>
					<option>中国农业银行</option>
					<option>招商银行</option>
				</select>
			</div>
			<div class="formfield kdId">
				<label class="label">开户名</label>
				<input type="text" class="ui-input">
			</div>
			<div class="formfield kdId">
				<label class="label">账 &nbsp; 号</label>
				<input type="text" class="ui-input">
			</div>
			<p class="radiobox">
				是否默认账户 
				<label class="ml10 mr15"><input type="radio" value="1" name="defaultbank"> <span>是</span></label>
				<label><input type="radio" value="0" name="defaultbank"> <span>否</span></label>
			</p>
			<p align="center" class="mt20"><input type="button" class="ui-btn1" value="确定"></p>
		</div>
	</div>
	<script src="static/js/bindBank.js"></script>
</body>
</html>