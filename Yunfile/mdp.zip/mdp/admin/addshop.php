<?php include('public/head.php');?>
<body>
	<div class="wrap">
		<?php include('public/top.php');?>
		<!-- End userState -->
		<div class="leftBgColor"></div>
		<div id="content">
			<?php include('public/left.php');?>
			<!-- End leftMenu -->
			<div class="mainbox">
				<div class="webAdrs">
					<a href="#">首页</a> / <a href="#">二级菜单</a> / <span>三级菜单</span>
				</div>
				<h1>店铺管理</h1>
				<div class="boxblock addshopfield">
					<div class="titleBox">添加新店</div>
					<table>
						<tr>
							<th><p>店铺名称：</p></th>
							<td><input type="text" class="ui-input shopName" name="shopName"></td>
						</tr>
						<tr>
							<th><p>品牌名称：</p></th>
							<td><input type="text" class="ui-input brandName" name="brandName"></td>
						</tr>
						<tr>
							<th><p>类目：</p></th>
							<td><input type="text" class="ui-input" value="家纺类" disabled="disabled"></td>
						</tr>
						<tr>
							<th><p>商标信息：</p></th>
							<td>
								<span class="uploadbox">
									<input type="file" id="UploadFile" name="UploadFile">
								</span>
								<span class="pictip">支持.jpg .bmp .gif格式照片，大小不超过2M</span>
							</td>
						</tr>
						<tr>
							<th></th>
							<td><input type="button" class="ui-btn1 subBtn" value="确 定"></td>
						</tr>
					</table>
				</div>
			</div>
			<!-- End mainBox -->
		</div>
		<!-- End content -->
	</div>
	<script src="./static/js/common/jquery.uploadify.min.js"></script>
	<script src="./static/js/addshop.js"></script>
</body>
</html>