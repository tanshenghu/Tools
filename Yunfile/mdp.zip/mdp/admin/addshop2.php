<?php include('public/head.php');?>
<body>
	<div class="wrap">
		<?php include('public/top.php');?>
		<!-- End userState -->
		<div class="leftBgColor"></div>
		<div id="content">
			<?php include('public/left.php');?>
			<!-- End leftMenu -->
			<div class="mainbox">
				<div class="webAdrs">
					<a href="#">首页</a> / <a href="#">二级菜单</a> / <span>三级菜单</span>
				</div>
				<h1>商品管理</h1>
				<div class="boxblock Faddnewshop">
					<div class="titleBox">添加商品</div>
					<form class="myform" method="post" acitve="#">
					<div class="formItemBox">
						<h4>基本信息</h4>
						<div class="ifieldbox">
							<div class="formfield">
								<label class="label">商品类目：</label>
								<select class="jq-cls1 parentshowerr" name="shopCls1">
									<option value="">请选择类目</option>
									<option>一级类目</option>
									<option>二级类目</option>
									<option>三级类目</option>
								</select>
								<select class="jq-cls2 ml30 parentshowerr" name="shopCls2">
									<option value="">请选择类目</option>
									<option>一级类目</option>
									<option>二级类目</option>
									<option>三级类目</option>
								</select>
							</div>
							<div class="formfield"><label class="label">商品标题：</label><input type="text" class="ui-input" name="shopTitle" maxlength="30"></div>
							<div class="formfield"><label class="label">商家编码：</label><input type="text" class="ui-input" name="shopCode"></div>
							<div class="formfield">
								<label class="label">商品类型：</label>
								<label class="checkinput mr50"><input type="radio" name="goodssort"><span>实物商品</span></label>
								<label class="checkinput"><input type="radio" name="goodssort"><span>虚拟商品</span></label>
							</div>
						</div>
					</div>
					<div class="formItemBox">
						<h4>库存/规格</h4>
						<div class="ifieldbox">
							<div class="formfield addrank">
								<label class="label">商品规格：</label>
								<select class="existlist">
									<option>长度</option>
								</select>
								<div class="clear"></div>
								<p class="mt7 undis addBtnBox"><input type="text" class="addListInput"><a href="javascript:;" class="addBtn">+添加</a></p>
								<span class="ui-btn3 mt7 dropdownbox">
									<span class="cinput">添加规格项目</span>
									<div class="downcontent">
										<a href="javascript:;" key="0">添加规格项目</a>
										<a href="javascript:;">长度</a>
										<a href="javascript:;">宽度</a>
										<a href="javascript:;">重量</a>
										<a href="javascript:;">颜色</a>
									</div>
								</span>
							</div>
							<div class="formfield kctab">
								<label class="label">商品库存：</label>
								<table>
									<thead>
										<tr>
											<th>长度</th>
											<th>商家编码</th>
											<th>库存</th>
											<th>市场价格</th>
											<th>建议售价</th>
											<th>代理价</th>
										</tr>
									</thead>
									<tr>
										<td><div class="Ssize">100cm</div></td>
										<td><input type="text" class="ui-input shoperId"></td>
										<td><input type="text" class="ui-input shopCount"></td>
										<td><input type="text" class="ui-input market"></td>
										<td><input type="text" class="ui-input propose"></td>
										<td><input type="text" class="ui-input agent"></td>
									</tr>
									<tfoot>
										<tr>
											<th colspan="6" align="left">批量设置： 
												<span class="setbox setprice">
													<a href="javascript:;">价格</a>
													<div class="downbox">
														<input type="text" class="ui-input"><input type="button" class="ui-btn1 OKBtn" value="确定">
													</div>
												</span>
												<span class="setbox setstock">
													<a href="javascript:;">库存</a>
													<div class="downbox">
														<input type="text" class="ui-input"><input type="button" class="ui-btn1 OKBtn" value="确定">
													</div>
												</span>
											</th>
										</tr>
									</tfoot>
								</table>
							</div>
							<div class="formfield">
								<label class="label">总库存：</label>
								<input type="text" class="ui-input kccount" readonly="readonly">
								<p class="formTip">总库存为 0 时，会上架到『已售罄的商品』列表里</p>
							</div>
						</div>
					</div>
					<div class="formItemBox">
						<h4>价格/图片</h4>
						<div class="ifieldbox">
							<div class="formfield"><label class="label">价格：</label><input type="text" class="ui-input CNYico"></div>
							<div class="formfield uploadbox">
								<label class="label">商品主图：</label>
								<input type="file" id="uploader">
								<p class="formTip" style="padding-top:90px;">建议尺寸：640 x 640 像素；您可以拖拽图片调整图片顺序。</p>
							</div>
						</div>
					</div>
					<div class="formItemBox">
						<h4>商品详情</h4>
						<div class="ifieldbox">
							<div class="formfield">
								<label class="label">商品详情：</label>
								<textarea name="content"></textarea>
							</div>
						</div>
					</div>
					<div class="formItemBox">
						<h4>物流/其它</h4>
						<div class="ifieldbox">
							<div class="formfield">
								<label class="label">运费设置：</label>
								<label class="checkinput"><input type="radio" name="freight"><span>统一邮费</span></label>
								<input type="text" class="ui-input CNYico">
								<p class="marH"></p>
								<label class="checkinput"><input type="radio" name="freight"><span>运费模版</span></label>
								<select>
									<option>没有可用运费模板</option>
								</select>
								<a href="javascript:;">刷新</a> <a href="javascript:;">+新建</a>
							</div>
							<div class="formfield">
								<label class="label">开售时间：</label>
								<label class="checkinput"><input type="radio" name="time"><span>立即开售</span></label>
								<p class="marH"></p>
								<label class="checkinput"><input type="radio" name="time"><span>定时开售</span></label>
								<input type="text" class="ui-input Wdate">
							</div>
							<div class="formfield">
								<label class="label">会员折扣：</label>
								<label class="checkinput"><input type="checkbox"><span>参加会员折扣</span></label>
							</div>
							<div class="formfield">
								<label class="label">发票：</label>
								<label class="checkinput"><input type="radio" name="invoice"><span>无</span></label>
								<label class="checkinput ml30"><input type="radio" name="invoice"><span>有</span></label>
							</div>
							<div class="formfield">
								<label class="label">保修：</label>
								<label class="checkinput"><input type="radio" name="guarantee"><span>无</span></label>
								<label class="checkinput ml30"><input type="radio" name="guarantee"><span>有</span></label>
							</div>
						</div>
					</div>
					<!-- end formitembox -->
					<p align="center" class="mb50"><input type="submit" value="保 存" class="ui-btn1"></p>
					</form>
				</div>
			</div>
			<!-- End mainBox -->
		</div>
		<!-- End content -->
	</div>
	<link rel="stylesheet" href="static/kindeditor/themes/default/default.css">
	<script src="static/js/common/jquery.validate.min.js"></script>
	<script src="static/js/common/validate.extend.js"></script>
	<script src="static/DatePicker/WdatePicker.js"></script>
	<script src="static/kindeditor/kindeditor-min.js"></script>
	<script src="static/kindeditor/lang/zh_CN.js"></script>
	<script src="static/js/common/jquery.uploadify.min.js"></script>
	<script src="static/js/addshop2.js"></script>
</body>
</html>