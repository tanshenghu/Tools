<?php include('public/head.php');?>
<body>
	<div class="wrap">
		<?php include('public/top.php');?>
		<!-- End userState -->
		<div class="leftBgColor"></div>
		<div id="content">
			<?php include('public/left.php');?>
			<!-- End leftMenu -->
			<div class="mainbox">
				<div class="webAdrs">
					<a href="#">首页</a> / <a href="#">二级菜单</a> / <span>三级菜单</span>
				</div>
				<h1>店铺管理</h1>
				<div class="boxblock onlineshoplist">
					<div class="titleBox">分享设置<a href="javascript:;" class="addnew addnewShare">新增</a></div>
					<table class="grid">
						<thead>
							<tr>
								<th width="100">序号</th>
								<th>账号</th>
								<th width="120">应用名称</th>
								<th width="120">密码</th>
								<th width="80">操作</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>001</td>
								<td>xiaowang00</td>
								<td><i class="share weibo"></i><span class="middle">微博</span></td>
								<td>9999</td>
								<td><a href="javascript:;" class="jq-share" data-content='{"name":"weibo","title":"xiaowang00"}'>分享</a></td>
							</tr>
							<tr>
								<td>002</td>
								<td>xiaowang01</td>
								<td><i class="share renren"></i><span class="middle">人人网</span></td>
								<td>9999</td>
								<td><a href="javascript:;" class="jq-share" data-content='{"name":"renren","title":"xiaowang01"}'>分享</a></td>
							</tr>
							<tr>
								<td>003</td>
								<td>xiaowang02</td>
								<td><i class="share shequ"></i><span class="middle">社区</span></td>
								<td>9999</td>
								<td><a href="javascript:;">分享</a></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			<!-- End mainBox -->
		</div>
		<!-- End content -->
	</div>
	<div class="popBox sharPop">
		<div class="titleBox">新增分享设置<span class="closeMe"></span></div>
		<div class="popCon">
			<table>
				<tr>
					<th width="15%">账号：</th>
					<td><input type="text" class="ui-input"></td>
					<th width="15%">密码：</th>
					<td><input type="password" class="ui-input"></td>
				</tr>
				<tr>
					<th>应用名称：</th>
					<td><select><option>应用名称1</option><option>应用名称2</option></select></td>
					<td colspan="2">
						<div style="padding-left:38px;">
							<label><input type="checkbox"><span class="middle hand ml3">同意授权平台推送消息</span></label>
						</div>
					</td>
				</tr>
				<tr>
					<td colspan="4" align="center">
						<input type="button" class="ui-btn1" value="确定">
						&nbsp;
						<input type="button" class="ui-btn2" value="取消">
					</td>
				</tr>
			</table>
		</div>
	</div>
	<script src="static/js/share.js"></script>
</body>
</html>