<div id="leftMenu">
	<div class="logo"></div>
	<ul>
		<li class="current"><a href="index.php"><i class="global_ico ico1"></i><span>首页</span></a></li>
		<li><a href="shopManage.php"><i class="global_ico ico2"></i><span>店铺管理</span></a></li>
		<li><a href="shoplist.php"><i class="global_ico ico2"></i><span>商品管理</span></a></li>
		<li><a href="share.php"><i class="global_ico ico2"></i><span>分享管理</span></a></li>
		<li><a href="market.php"><i class="global_ico ico3"></i><span>分销商管理</span></a></li>
		<li><a href="jurisdiction.php"><i class="global_ico ico4"></i><span>权限管理</span></a></li>
		<li><a href="order.php"><i class="global_ico ico5"></i><span>订单管理</span></a></li>
		<li><a href="#"><i class="global_ico ico6"></i><span>数据分析</span></a></li>
		<li><a href="#"><i class="global_ico ico7"></i><span>绑定银行账户</span></a></li>
	</ul>
</div>