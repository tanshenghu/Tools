<!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>品牌商后台管理系统</title>
	<link rel="stylesheet" href="static/style/style.css">
	
	<link rel="stylesheet/less" href="static/style/style.less">
	<script src="static/js/less.min.js"></script>
	<script src="static/js/common/jquery.js"></script>
	<script src="static/js/common/common.js"></script>
	<script src="static/js/common/main.js"></script>
</head>