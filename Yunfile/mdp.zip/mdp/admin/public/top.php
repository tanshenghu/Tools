<div class="userState">
	<div class="lbox">商品后台管理系统<label>v1.0</label></div>
	<div class="rbox">
		<span class="manager">
			<img src="static/images/user.gif" class="userPhoto" alt="admin" alt="admin">
			<label>管理员</label><i class="global_ico arrows_ico"></i>
			<div class="mandropset">
				<a href="#">会员管理</a>
				<a href="#">会员管理</a>
				<a href="#">退出</a>
			</div>
		</span>
	</div>
</div>