<?php include('public/head.php');?>
<body>
	<div class="wrap">
		<?php include('public/top.php');?>
		<!-- End userState -->
		<div class="leftBgColor"></div>
		<div id="content">
			<?php include('public/left.php');?>
			<!-- End leftMenu -->
			<div class="mainbox">
				<div class="webAdrs">
					<a href="#">首页</a> / <a href="#">二级菜单</a> / <span>三级菜单</span>
				</div>
				<h1>会员管理</h1>
				<div class="boxblock member">
					<div class="titleBox">会员统计</div>
					<dl>
						<dd>
							<span class="blue">100</span>
							<p>会员总数</p>
							<p class="wire"></p>
						</dd>
						<dd>
							<span class="blue">100</span>
							<p>今日新增会员</p>
							<p class="wire"></p>
						</dd>
						<dd>
							<span class="blue">100</span>
							<p>本月新增会员</p>
							<p class="wire"></p>
						</dd>
						<dd>
							<span class="blue">100</span>
							<p>预留字段</p>
						</dd>
					</dl>
				</div>
				<div class="boxblock searchshoplist">
					<div class="titleBox">会员信息</div>
					<table class="grid">
						<thead>
							<tr>
								<th width="120">ID</th>
								<th>会员姓名</th>
								<th width="150">手机号码</th>
								<th width="150">微信号</th>
								<th width="150">微博号</th>
								<th width="85">操作</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>0001</td>
								<td>xiaowang123</td>
								<td>13344568941</td>
								<td>xiaowang123</td>
								<td>xiaowang123</td>
								<td><a href="memberOrder.php">查看订单</a></td>
							</tr>
							<tr>
								<td>0001</td>
								<td>xiaowang123</td>
								<td>13344568941</td>
								<td>xiaowang123</td>
								<td>xiaowang123</td>
								<td><a href="#">查看订单</a></td>
							</tr>
							<tr>
								<td>0001</td>
								<td>xiaowang123</td>
								<td>13344568941</td>
								<td>xiaowang123</td>
								<td>xiaowang123</td>
								<td><a href="#">查看订单</a></td>
							</tr>
							<tr>
								<td>0001</td>
								<td>xiaowang123</td>
								<td>13344568941</td>
								<td>xiaowang123</td>
								<td>xiaowang123</td>
								<td><a href="#">查看订单</a></td>
							</tr>
							<tr>
								<td>0001</td>
								<td>xiaowang123</td>
								<td>13344568941</td>
								<td>xiaowang123</td>
								<td>xiaowang123</td>
								<td><a href="#">查看订单</a></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			<!-- End mainBox -->
		</div>
		<!-- End content -->
	</div>
</body>
</html>