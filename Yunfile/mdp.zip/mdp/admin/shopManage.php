<?php include('public/head.php');?>
<body>
	<div class="wrap">
		<?php include('public/top.php');?>
		<!-- End userState -->
		<div class="leftBgColor"></div>
		<div id="content">
			<?php include('public/left.php');?>
			<!-- End leftMenu -->
			<div class="mainbox">
				<div class="webAdrs">
					<a href="#">首页</a> / <a href="#">二级菜单</a> / <span>三级菜单</span>
				</div>
				<h1>店铺管理</h1>
				<div class="boxblock searchInfo">
					<div class="titleBox">搜索</div>
					<table>
						<tr>
							<th width="50">名称：</th>
							<td width="150"><input type="text" class="ui-input" name="name"></td>
							<th width="70">负责人：</th>
							<td width="150"><input type="text" class="ui-input" name="person"></td>
							<th width="50">类目：</th>
							<td width="150">
								<select>
									<option>类目一</option>
									<option>类目二</option>
									<option>家纺类</option>
								</select>
							</td>
							<th width="50">状态：</th>
							<td>
								<select>
									<option>正常</option>
									<option>异常</option>
									<option>注销</option>
								</select>
							</td>
						</tr>
						<tr>
							<th>预留：</th>
							<td colspan="3"><input type="text" class="ui-input stay"></td>
							<td colspan="4" align="right">
								<div class="pr70">
									<a href="javascript:;" class="middle inputEmpty mr20">清空条件</a>
									<input type="button" class="ui-btn1 searchBtn" value="搜 索">
								</div>
							</td>
						</tr>
					</table>
				</div>
				<div class="boxblock searchshoplist">
					<div class="titleBox">店铺列表<a href="addshop.php" class="addnew">添加新店</a></div>
					<table class="grid">
						<thead>
							<tr>
								<th>名称</th>
								<th width="150">类目</th>
								<th width="120">负责人</th>
								<th width="120">联系方式</th>
								<th width="100">状态</th>
								<th width="80">操作</th>
							</tr>
						</thead>
					</table>
				</div>
			</div>
			<!-- End mainBox -->
		</div>
		<!-- End content -->
	</div>
	<script src="static/js/common/easygrid.js"></script>
	<script src="static/js/shopManage.js"></script>
</body>
</html>