<?php include('public/head.php');?>
<body>
	<div class="wrap">
		<?php include('public/top.php');?>
		<!-- End userState -->
		<div class="leftBgColor"></div>
		<div id="content">
			<?php include('public/left.php');?>
			<!-- End leftMenu -->
			<div class="mainbox">
				<div class="webAdrs">
					<a href="#">首页</a> / <a href="#">二级菜单</a> / <span>三级菜单</span>
				</div>
				<h1>商品管理</h1>
				<div class="boxblock searchInfo">
					<div class="titleBox">搜索</div>
					<table>
						<tr>
							<th width="50">名称：</th>
							<td width="150"><input type="text" class="ui-input"></td>
							<th width="70">编码：</th>
							<td width="150"><input type="text" class="ui-input"></td>
							<th width="50">类目：</th>
							<td width="150">
								<select>
									<option>类目一</option>
									<option>类目二</option>
									<option>家纺类</option>
								</select>
							</td>
							<th width="50">状态：</th>
							<td>
								<select>
									<option>正常</option>
									<option>异常</option>
									<option>注销</option>
								</select>
							</td>
						</tr>
						<tr>
							<th>价格：</th>
							<td colspan="3" class="priceinterval">
								<input type="text" class="ui-input">
								<label>至</label>
								<input type="text" class="ui-input">
							</td>
							<td colspan="4" align="right">
								<div class="pr70">
									<a href="javascript:;" class="middle inputEmpty mr20">清空条件</a>
									<input type="button" class="ui-btn1" value="搜 索">
								</div>
							</td>
						</tr>
					</table>
				</div>
				<div class="boxblock searchshoplist">
					<div class="titleBox">商品列表<a href="addnewshop.php" class="addnew">添加商品</a></div>
					<table class="grid">
						<thead>
							<tr>
								<th width="70"><label class="hand"><input type="checkbox" class="checkAll mr3">全选</label></th>
								<th width="110">编码</th>
								<th>名称</th>
								<th width="100">类目</th>
								<th width="110">价格</th>
								<th width="85">状态</th>
								<th width="130">操作</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><input type="checkbox"></td>
								<td>100</td>
								<td>东莞远梦超级蚕丝被四件套</td>
								<td>家纺类</td>
								<td>999</td>
								<td><span class="list-status1">上架</span></td>
								<td><a href="#">下架</a> <a href="#">编辑</a> <a href="#">删除</a></td>
							</tr>
							<tr>
								<td><input type="checkbox"></td>
								<td>100</td>
								<td>东莞远梦超级蚕丝被四件套</td>
								<td>家纺类</td>
								<td>999</td>
								<td><span class="list-status3">下架</span></td>
								<td><a href="#">下架</a> <a href="#">编辑</a> <a href="#">删除</a></td>
							</tr>
							<tr>
								<td><input type="checkbox"></td>
								<td>19</td>
								<td>东莞远梦超级蚕丝被四件套</td>
								<td>家纺类</td>
								<td>999</td>
								<td><span class="list-status3">下架</span></td>
								<td><a href="#">下架</a> <a href="#">编辑</a> <a href="#">删除</a></td>
							</tr>
							<tr>
								<td><input type="checkbox"></td>
								<td>19</td>
								<td>东莞远梦超级蚕丝被四件套</td>
								<td>家纺类</td>
								<td>999</td>
								<td><span class="list-status1">上架</span></td>
								<td><a href="#">下架</a> <a href="#">编辑</a> <a href="#">删除</a></td>
							</tr>
						</tbody>
					</table>
					<div class="paging">
						<ul>
							<li class="indexpage nopage"><span>首页</span></li>
							<li class="prevpage nopage"><span>上一页</span></li>
							<li class="current"><a href="#1">1</a></li>
							<li><a href="#2">2</a></li>
							<li><a href="#3">3</a></li>
							<li><a href="#4">4</a></li>
							<li><a href="#5">5</a></li>
							<li><a href="#6">6</a></li>
							<li><a href="#7">7</a></li>
							<li><a href="#8">8</a></li>
							<li><a href="#9">9</a></li>
							<li><a href="#10">10</a></li>
							<li class="ellpage"><span>...</span></li>
							<li class="nextpage"><a href="#">下一页</a></li>
							<li class="endpage"><a href="#">尾页</a></li>
						</ul>
					</div>
				</div>
			</div>
			<!-- End mainBox -->
		</div>
		<!-- End content -->
	</div>
	<script src="static/js/shoplist.js"></script>
</body>
</html>