<?php include('public/head.php');?>
<body>
	<div class="wrap">
		<?php include('public/top.php');?>
		<!-- End userState -->
		<div class="leftBgColor"></div>
		<div id="content">
			<?php include('public/left.php');?>
			<!-- End leftMenu -->
			<div class="mainbox">
				<div class="webAdrs">
					<a href="#">首页</a> / <a href="#">二级菜单</a> / <span>三级菜单</span>
				</div>
				<h1>商品管理</h1>
				<div class="boxblock addnewshop">
					<div class="titleBox">添加商品</div>
					<table>
						<tr>
							<th width="15%" height="50">商品标题：</th>
							<td width="30%"><input type="text" class="ui-input" name="shoptitle" maxlength="30"></td>
							<th width="15%">商品类目：</th>
							<td>
								<select name="shoptype">
									<option>商品类目1</option>
									<option>商品类目2</option>
								</select>
							</td>
						</tr>
						<tr>
							<th height="50">商品编码：</th>
							<td><input type="text" class="ui-input" name="shopcode"></td>
							<th rowspan="3">商品图片：</th>
							<td rowspan="3">
								<div class="uppicbox">
									<ol class="clearfix">
										<li>
											<div class="resultPic"><img src="static/images/pic.jpg"></div>
											<input type="file" id="UploadFile_1" class="UploadFile" name="UploadFile">
										</li>
										<li>
											<div class="resultPic"><img src="static/images/pic.jpg"></div>
											<input type="file" id="UploadFile_2" class="UploadFile" name="UploadFile">
										</li>
										<li>
											<div class="resultPic"></div>
											<input type="file" id="UploadFile_3" class="UploadFile" name="UploadFile">
										</li>
										<li>
											<div class="resultPic"></div>
											<input type="file" id="UploadFile_4" class="UploadFile" name="UploadFile">
										</li>
										<li>
											<div class="resultPic"></div>
											<input type="file" id="UploadFile_5" class="UploadFile" name="UploadFile">
										</li>
									</ol>
									<input type="hidden" id="uploadpath" name="uploadpath">
								</div>
								<p class="formTip mt10">提示：本地上传图片大小不能超过500K。<br>本类目下您最多可以上传 5 张图片。</p>
							</td>
						</tr>
						<tr>
							<th height="50">商品库存：</th>
							<td><input type="text" class="ui-input" name="inventory"></td>
						</tr>
						<tr>
							<th height="50">商品价格：</th>
							<td><input type="text" class="ui-input" name="shopprice"></td>
						</tr>
						<tr>
							<th></th>
							<td colspan="3">
								<textarea name="content" style="width:580px;height:45px;"></textarea>
							</td>
						</tr>
					</table>
					<p align="center" class="pb30 mt30"><input type="button" class="ui-btn1 submit" value="确 定"></p>
				</div>
			</div>
			<!-- End mainBox -->
		</div>
		<!-- End content -->
	</div>
	<link rel="stylesheet" href="static/kindeditor/themes/default/default.css">
	<script src="static/kindeditor/kindeditor-min.js"></script>
	<script src="static/kindeditor/lang/zh_CN.js"></script>
	<script src="static/js/common/jquery.uploadify.min.js"></script>
	<script src="static/js/addnewshop.js"></script>
</body>
</html>