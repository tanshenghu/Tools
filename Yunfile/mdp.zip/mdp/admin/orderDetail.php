<?php include('public/head.php');?>
<body>
	<div class="wrap">
		<?php include('public/top.php');?>
		<!-- End userState -->
		<div class="leftBgColor"></div>
		<div id="content">
			<?php include('public/left.php');?>
			<!-- End leftMenu -->
			<div class="mainbox">
				<div class="webAdrs">
					<a href="#">首页</a> / <a href="#">二级菜单</a> / <span>三级菜单</span>
				</div>
				<h1>订单详情</h1>
				<div class="boxblock orderDetail">
					<div class="titleBox">订单信息</div>
					<table class="orderfield">
						<tr>
							<th>订单号：</th>
							<td colspan="5">2014121511504003333</td>
						</tr>
						<tr>
							<th width="120">下单时间：</th>
							<td width="200">2014-12-15 11:50</td>
							<th width="150">订单人：</th>
							<td width="120">张三</td>
							<th width="150">手机号：</th>
							<td>13832242545</td>
						</tr>
						<tr>
							<th>收货人：</th>
							<td>张三</td>
							<th>收货地址：</th>
							<td colspan="3">广东省东莞市厚街镇</td>
						</tr>
						<tr>
							<th>发货时间：</th>
							<td>2014-12-15</td>
							<th>确认时间：</th>
							<td colspan="3">2014-12-18</td>
						</tr>
					</table>
					<div>
						<table class="grid">
							<thead bgcolor="#f3f3f3">
								<tr>
									<th class="sendPopBtn">商品名称及规格</th>
									<th>销售价格</th>
									<th>数量</th>
									<th>金额</th>
									<th>操作</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td><div class="picbox2"><img src="static/images/pic.jpg"><span>远梦床上四件套</span><p>红色<br>100cm x 100cm</p></div></td>
									<td>999.00</td>
									<td>999</td>
									<td>999</td>
									<td><p align="center"><a href="#">取消订单</a><br><a href="#">退货</a><br><a href="#">查看物流</a></p></td>
								</tr>
								<tr>
									<td><div class="picbox2"><img src="static/images/pic_2.jpg"><span>远梦床上四件套</span><p>红色<br>100cm x 100cm</p></div></td>
									<td>999.00</td>
									<td>999</td>
									<td>999</td>
									<td><p align="center"><a href="#">取消订单</a><br><a href="#">退货</a><br><a href="#">查看物流</a></p></td>
								</tr>
								<tr>
									<td><div class="picbox2"><img src="static/images/pic_3.jpg"><span>远梦床上四件套</span><p>红色<br>100cm x 100cm</p></div></td>
									<td>999.00</td>
									<td>999</td>
									<td>999</td>
									<td><p align="center"><a href="#">取消订单</a><br><a href="#">退货</a><br><a href="#">查看物流</a></p></td>
								</tr>
								<tr>
									<td><div class="picbox2"><img src="static/images/pic.jpg"><span>远梦床上四件套</span><p>红色<br>100cm x 100cm</p></div></td>
									<td>999.00</td>
									<td>999</td>
									<td>999</td>
									<td><p align="center"><a href="#">取消订单</a><br><a href="#">退货</a><br><a href="#">查看物流</a></p></td>
								</tr>
								<tr>
									<td><div class="picbox2"><img src="static/images/pic_2.jpg"><span>远梦床上四件套</span><p>红色<br>100cm x 100cm</p></div></td>
									<td>999.00</td>
									<td>999</td>
									<td>999</td>
									<td><p align="center"><a href="#">取消订单</a><br><a href="#">退货</a><br><a href="#">查看物流</a></p></td>
								</tr>
								<tr>
									<td><div class="picbox2"><img src="static/images/pic_3.jpg"><span>远梦床上四件套</span><p>红色<br>100cm x 100cm</p></div></td>
									<td>999.00</td>
									<td>999</td>
									<td>999</td>
									<td><p align="center"><a href="#">取消订单</a><br><a href="#">退货</a><br><a href="#">查看物流</a></p></td>
								</tr>
							</tbody>
						</table>
						<div class="paging">
						<ul>
							<li class="indexpage nopage"><span>首页</span></li>
							<li class="prevpage nopage"><span>上一页</span></li>
							<li class="current"><a href="#1">1</a></li>
							<li><a href="#2">2</a></li>
							<li><a href="#3">3</a></li>
							<li><a href="#4">4</a></li>
							<li><a href="#5">5</a></li>
							<li><a href="#6">6</a></li>
							<li><a href="#7">7</a></li>
							<li><a href="#8">8</a></li>
							<li><a href="#9">9</a></li>
							<li><a href="#10">10</a></li>
							<li class="ellpage"><span>...</span></li>
							<li class="nextpage"><a href="#">下一页</a></li>
							<li class="endpage"><a href="#">尾页</a></li>
						</ul>
					</div>
					</div>
				</div>
			</div>
			<!-- End mainBox -->
		</div>
		<!-- End content -->
	</div>
	<!-- 弹出层 -->
	<div class="popBox sendPop">
		<div class="titleBox">发货<span class="closeMe" title="关闭"></span></div>
		<div class="popCon">
			<div class="formfield kd">
				<label class="label">物流商</label>
				<select>
					<option>顺风</option>
					<option>韵达</option>
				</select>
			</div>
			<div class="formfield kdId">
				<label class="label">物流单号</label>
				<input type="text" class="ui-input">
			</div>
			<p align="center" class="mt40"><input type="button" class="ui-btn1" value="确定"></p>
		</div>
	</div>
	<script src="static/js/orderDetail.js"></script>
</body>
</html>