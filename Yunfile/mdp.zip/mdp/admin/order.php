<?php include('public/head.php');?>
<body>
	<div class="wrap">
		<?php include('public/top.php');?>
		<!-- End userState -->
		<div class="leftBgColor"></div>
		<div id="content">
			<?php include('public/left.php');?>
			<!-- End leftMenu -->
			<div class="mainbox">
				<div class="webAdrs">
					<a href="#">首页</a> / <a href="#">二级菜单</a> / <span>三级菜单</span>
				</div>
				<h1>订单管理</h1>
				<div class="boxblock searchInfo">
					<div class="titleBox">搜索</div>
					<table>
						<tr>
							<th width="50">名称：</th>
							<td width="150"><input type="text" class="ui-input"></td>
							<th width="70">负责人：</th>
							<td width="150"><input type="text" class="ui-input"></td>
							<th width="50">类目：</th>
							<td width="150">
								<select>
									<option>类目一</option>
									<option>类目二</option>
									<option>家纺类</option>
								</select>
							</td>
							<th width="50">状态：</th>
							<td>
								<select>
									<option>正常</option>
									<option>异常</option>
									<option>注销</option>
								</select>
							</td>
						</tr>
						<tr>
							<th>预留：</th>
							<td colspan="3"><input type="text" class="ui-input stay"></td>
							<td colspan="4" align="right">
								<div class="pr70">
									<a href="javascript:;" class="middle inputEmpty mr20">清空条件</a>
									<input type="button" class="ui-btn1" value="搜 索">
								</div>
							</td>
						</tr>
					</table>
				</div>
				<div class="boxblock searchshoplist">
					<div class="titleBox">订单列表</div>
					<table class="grid">
						<thead>
							<tr>
								<th width="100">订单号</th>
								<th>商品名称</th>
								<th width="120">订单人</th>
								<th width="120">订单人手机</th>
								<th width="130">价格</th>
								<th width="100">数量</th>
								<th width="80">操作</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><a href="orderDetail.php">10000000</a></td>
								<td>
									<div class="picbox">
										<img src="static/images/pic.jpg"><span>远梦真丝四件套</span>
									</div>
								</td>
								<td>小王</td>
								<td>13311223344</td>
								<td>998</td>
								<td>100</td>
								<td>已取消</td>
							</tr>
							<tr>
								<td>10000000</td>
								<td>
									<div class="picbox">
										<img src="static/images/pic.jpg"><span>远梦真丝四件套</span>
									</div>
								</td>
								<td>小王</td>
								<td>13311223344</td>
								<td>998</td>
								<td>100</td>
								<td><a href="#">取消订单</a></td>
							</tr>
							<tr>
								<td>10000000</td>
								<td>
									<div class="picbox">
										<img src="static/images/pic.jpg"><span>远梦真丝四件套</span>
									</div>
								</td>
								<td>小王</td>
								<td>13311223344</td>
								<td>998</td>
								<td>100</td>
								<td><a href="#">取消订单</a></td>
							</tr>
							<tr>
								<td>10000000</td>
								<td>
									<div class="picbox">
										<img src="static/images/pic.jpg"><span>远梦真丝四件套</span>
									</div>
								</td>
								<td>小王</td>
								<td>13311223344</td>
								<td>998</td>
								<td>100</td>
								<td><a href="#">取消订单</a></td>
							</tr>
						</tbody>
					</table>
					<div class="paging">
						<ul>
							<li class="indexpage nopage"><span>首页</span></li>
							<li class="prevpage nopage"><span>上一页</span></li>
							<li class="current"><a href="#1">1</a></li>
							<li><a href="#2">2</a></li>
							<li><a href="#3">3</a></li>
							<li><a href="#4">4</a></li>
							<li><a href="#5">5</a></li>
							<li><a href="#6">6</a></li>
							<li><a href="#7">7</a></li>
							<li><a href="#8">8</a></li>
							<li><a href="#9">9</a></li>
							<li><a href="#10">10</a></li>
							<li class="ellpage"><span>...</span></li>
							<li class="nextpage"><a href="#">下一页</a></li>
							<li class="endpage"><a href="#">尾页</a></li>
						</ul>
					</div>
				</div>
			</div>
			<!-- End mainBox -->
		</div>
		<!-- End content -->
	</div>
	<script>
	
	</script>
</body>
</html>