<?php include('public/head.php');?>
<body>
	<div class="wrap">
		<?php include('public/top.php');?>
		<!-- End userState -->
		<div class="leftBgColor"></div>
		<div id="content">
			<?php include('public/left.php');?>
			<!-- End leftMenu -->
			<div class="mainbox Index">
				<div class="webAdrs">
					<a href="#">首页</a> / <a href="#">二级菜单</a> / <span>三级菜单</span>
				</div>
				<h1>首页</h1>
				<div class="boxblock capitalMsg">
					<div class="titleBox">资金信息</div>
					<ol>
						<li class="surplus">
							<h3>账户余额</h3>
							<p>&yen;88,888,000</p>
						</li>
						<li class="usable">
							<h3>可用余额</h3>
							<p>&yen;888,000</p>
						</li>
						<li class="disabled">
							<h3>冻结金额</h3>
							<p>&yen;7,000,000</p>
						</li>
						<li class="withdraw"><a href="javascript:;">提现</a></li>
					</ol>
				</div>
				<div class="boxblock dataInfo">
					<div class="titleBox">数据分析</div>
					<dl>
						<dd>今日销售 <b class="blue fz28">100</b> 单<p class="wire"></p></dd>
						<dd>营业额 <b class="blue fz28">9999</b> 元<p class="wire"></p></dd>
						<dd class="conDetail">
							<p>销售额最高店铺：<span class="blue">XXXX</span>店</p>
							<p>今日发展了 <span class="blue">99</span> 家分销商</p>
							<p>今日 <span class="blue">小王</span> 发展了最多的分销商</p>
						</dd>
					</dl>
				</div>
			</div>
			<!-- End mainBox -->
		</div>
		<!-- End content -->
	</div>
	<div class="popBox tx">
		<div class="titleBox">提现<span class="closeMe" title="关闭"></span></div>
		<table class="poptx popTpl">
			<tr>
				<td width="32%" align="right" valign="top">提现方式</td>
				<td>
					<div class="selsortbox">
						<ul><li class="alipay" title="支付宝"><i></i><label>支付宝</label></li></ul>
						<ol class="paysort">
							<li class="alipay" title="支付宝"><i></i><label>支付宝</label></li>
							<li class="bank" title="银行卡"><i></i><label>银行卡</label></li>
						</ol>
					</div>
				</td>
			</tr>
			<tr>
				<td align="right">提现金额</td>
				<td><input type="text" class="ui-input moneyCount"></td>
			</tr>
			<tr>
				<td colspan="2" class="note"><p>注：提现金额不能大于可用余额</p></td>
			</tr>
			<tr>
				<td colspan="2" align="center"><input type="button" class="ui-btn1 okBtn" value="确 定"></td>
			</tr>
		</table>
	</div>
	<!-- popup -->
	<script src="./static/js/index.js"></script>
	<script>
	var currentMenuId = 0;
	</script>
</body>
</html>