<?php include('public/head.php');?>
<body>
	<div class="wrap">
		<?php include('public/top.php');?>
		<!-- End userState -->
		<div class="leftBgColor"></div>
		<div id="content">
			<?php include('public/left.php');?>
			<!-- End leftMenu -->
			<div class="mainbox">
				<div class="webAdrs">
					<a href="#">首页</a> / <a href="#">二级菜单</a> / <span>三级菜单</span>
				</div>
				<h1>权限管理</h1>
				<div class="boxblock searchshoplist">
					<div class="titleBox">用户列表<a href="addnewuser.php" class="addnew">新增用户</a></div>
					<table class="grid">
						<thead>
							<tr>
								<th>姓名</th>
								<th>手机号码</th>
								<th>角色</th>
								<th>状态</th>
								<th>操作</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>张三丰</td>
								<td>13012345678</td>
								<td>管理员</td>
								<td><span class="list-status1">正常</span></td>
								<td><a href="#">管理</a> <a href="#">注销</a></td>
							</tr>
							<tr>
								<td>小王</td>
								<td>13012345678</td>
								<td>管理员</td>
								<td><span class="list-status1">正常</span></td>
								<td><a href="#">管理</a> <a href="#">注销</a></td>
							</tr>
							<tr>
								<td>张三丰</td>
								<td>13012345678</td>
								<td>管理员</td>
								<td><span class="list-status1">正常</span></td>
								<td><a href="#">管理</a> <a href="#">注销</a></td>
							</tr>
							<tr>
								<td>小王</td>
								<td>13012345678</td>
								<td>管理员</td>
								<td><span class="list-status1">正常</span></td>
								<td><a href="#">管理</a> <a href="#">注销</a></td>
							</tr>
							<tr>
								<td>张三丰</td>
								<td>13012345678</td>
								<td>管理员</td>
								<td><span class="list-status1">正常</span></td>
								<td><a href="#">管理</a> <a href="#">注销</a></td>
							</tr>
							<tr>
								<td>小王</td>
								<td>13012345678</td>
								<td>管理员</td>
								<td><span class="list-status1">正常</span></td>
								<td><a href="#">管理</a> <a href="#">注销</a></td>
							</tr>
							<tr>
								<td>张三丰</td>
								<td>13012345678</td>
								<td>管理员</td>
								<td><span class="list-status1">正常</span></td>
								<td><a href="#">管理</a> <a href="#">注销</a></td>
							</tr>
							<tr>
								<td>小王</td>
								<td>13012345678</td>
								<td>管理员</td>
								<td><span class="list-status1">正常</span></td>
								<td><a href="#">管理</a> <a href="#">注销</a></td>
							</tr>
						</tbody>
					</table>
					<div class="paging">
						<ul>
							<li class="indexpage nopage"><span>首页</span></li>
							<li class="prevpage nopage"><span>上一页</span></li>
							<li class="current"><a href="#1">1</a></li>
							<li><a href="#2">2</a></li>
							<li><a href="#3">3</a></li>
							<li><a href="#4">4</a></li>
							<li><a href="#5">5</a></li>
							<li><a href="#6">6</a></li>
							<li><a href="#7">7</a></li>
							<li><a href="#8">8</a></li>
							<li><a href="#9">9</a></li>
							<li><a href="#10">10</a></li>
							<li class="ellpage"><span>...</span></li>
							<li class="nextpage"><a href="#">下一页</a></li>
							<li class="endpage"><a href="#">尾页</a></li>
						</ul>
					</div>
				</div>
			</div>
			<!-- End mainBox -->
		</div>
		<!-- End content -->
	</div>
	<script>
	//seajs.use();
	</script>
</body>
</html>