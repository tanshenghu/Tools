<?php include('public/head.php');?>
<body>
	<div class="wrap">
		<?php include('public/top.php');?>
		<!-- End userState -->
		<div class="leftBgColor"></div>
		<div id="content">
			<?php include('public/left.php');?>
			<!-- End leftMenu -->
			<div class="mainbox">
				<div class="webAdrs">
					<a href="#">首页</a> / <a href="#">二级菜单</a> / <span>三级菜单</span>
				</div>
				<h1>权限管理</h1>
				<div class="boxblock addNewUser">
					<div class="titleBox">添加新用户</div>
					<dl class="clearfix">
						<dt>
							<table>
								<tr>
									<th width="80"><p class="thpdg">姓名：</p></th>
									<td>
										<input type="text" class="ui-input">
										<p class="formTip">请填写用户姓名</p>
									</td>
								</tr>
								<tr>
									<th><p class="thpdg">手机号：</p></th>
									<td>
										<input type="text" class="ui-input">
										<p class="formTip">请填写用户手机号</p>
									</td>
								</tr>
								<tr>
									<th valign="top"><p class="thpdg">角色：</p></th>
									<td>
										<div class="setrole">
											<select>
												<option>管理员</option>
												<option>普通会员</option>
											</select>
											<p class="formTip">请选择用户角色</p>
											<p class="userSet"><a href="javascript:;">点击设置</a></p>
										</div>
									</td>
								</tr>
								<tr>
									<th>状态：</th>
									<td>
										<label>正常</label>&nbsp; &nbsp; &nbsp; &nbsp;
										<a href="javascript:;" class="ml50">点击注销</a>
									</td>
								</tr>
								<tr>
									<td colspan="2" align="center">
										<input type="button" class="ui-btn1" value="确 定">
									</td>
								</tr>
							</table>
						</dt>
						<dd><img src="static/images/eg_01.jpg"></dd>
					</dl>
				</div>
			</div>
			<!-- End mainBox -->
		</div>
		<!-- End content -->
	</div>
	<script>
	//seajs.use();
	</script>
</body>
</html>