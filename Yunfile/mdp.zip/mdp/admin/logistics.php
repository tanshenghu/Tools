<?php include('public/head.php');?>
<body>
	<div class="wrap">
		<?php include('public/top.php');?>
		<!-- End userState -->
		<div class="leftBgColor"></div>
		<div id="content">
			<?php include('public/left.php');?>
			<!-- End leftMenu -->
			<div class="mainbox">
				<div class="webAdrs">
					<a href="#">首页</a> / <a href="#">二级菜单</a> / <span>三级菜单</span>
				</div>
				<h1>订单详情</h1>
				<div class="boxblock logistics">
					<div class="titleBox">物流信息</div>
					<div class="orderNum">
						<strong>订单号：</strong>2014121511504003333
						<strong class="ml50">创建时间：</strong>2014-12-16 17:28
					</div>
					<div class="logisList">
						<p><label>发货方式：</label>快递</p>
						<p><label>物流公司：</label>申通快递</p>
						<p><label>运单号码：</label>968126518523</p> 
						<div class="infoMsg">
							<label>物流跟踪：</label>
							<ol>
								<li>2014-12-16 17:35:22 卖家已发货</li>
								<li>2014-12-16 18:06:30 【河北石家庄东开发区】的收件员【任豪】已收件</li>
								<li>2014-12-16 21:57:50 【河北石家庄公司】正在进行【装袋】扫描</li>
								<li>2014-12-16 21:57:50 由【河北石家庄公司】发往【河北石家庄航空部】</li>
								<li>2014-12-16 22:06:42 由【河北石家庄公司】发往【河北石家庄航空部】</li>
								<li>2014-12-16 22:08:54 由【河北石家庄航空部】发往【浙江杭州中转部】</li>
								<li>2014-12-17 20:30:21 由【浙江杭州中转部】发往【浙江杭州余杭公司】 </li>
								<li>2014-12-18 08:15:16 【浙江杭州余杭公司】已收入</li>
								<li>2014-12-18 08:15:16 【浙江杭州余杭公司】的派件员【党校】正在派件</li>
							</ol>
						</div>
					</div>
				</div>
			</div>
			<!-- End mainBox -->
		</div>
		<!-- End content -->
	</div>
</body>
</html>