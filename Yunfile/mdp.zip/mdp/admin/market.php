<?php include('public/head.php');?>
<body>
	<div class="wrap">
		<?php include('public/top.php');?>
		<!-- End userState -->
		<div class="leftBgColor"></div>
		<div id="content">
			<?php include('public/left.php');?>
			<!-- End leftMenu -->
			<div class="mainbox">
				<div class="webAdrs">
					<a href="#">首页</a> / <a href="#">二级菜单</a> / <span>三级菜单</span>
				</div>
				<h1>分销商管理</h1>
				<div class="boxblock searchInfo">
					<div class="titleBox">搜索</div>
					<table>
						<tr>
							<th width="50">名称：</th>
							<td width="150"><input type="text" class="ui-input"></td>
							<th width="70">负责人：</th>
							<td width="150"><input type="text" class="ui-input"></td>
							<th width="50">类目：</th>
							<td width="150">
								<select>
									<option>类目一</option>
									<option>类目二</option>
									<option>家纺类</option>
								</select>
							</td>
							<th width="50">状态：</th>
							<td>
								<select>
									<option>正常</option>
									<option>异常</option>
									<option>注销</option>
								</select>
							</td>
						</tr>
						<tr>
							<th>预留：</th>
							<td colspan="3"><input type="text" class="ui-input stay"></td>
							<td colspan="4" align="right">
								<div class="pr70">
									<a href="javascript:;" class="middle inputEmpty mr20">清空条件</a>
									<input type="button" class="ui-btn1" value="搜 索">
								</div>
							</td>
						</tr>
					</table>
				</div>
				<div class="boxblock searchshoplist">
					<div class="titleBox">分销商列表<a href="javascript:;" class="addnew send-inviteCode">发送邀请码</a></div>
					<table class="grid">
						<thead>
							<tr>
								<th width="100">姓名</th>
								<th>所开店铺</th>
								<th width="120">手机号码</th>
								<th width="120">微信</th>
								<th width="130">微博</th>
								<th width="100">QQ</th>
								<th width="80">状态</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>张三丰</td>
								<td>东莞远梦旗舰店</td>
								<td>13012345678</td>
								<td>zhangsan.001</td>
								<td>zhangsan.001</td>
								<td>112234967</td>
								<td><span class="list-status1">正常</span></td>
							</tr>
							<tr>
								<td>张三丰</td>
								<td>东莞远梦旗舰店</td>
								<td>13012345678</td>
								<td>zhangsan.001</td>
								<td>zhangsan.001</td>
								<td>112234967</td>
								<td><span class="list-status1">正常</span></td>
							</tr>
							<tr>
								<td>张三丰</td>
								<td>东莞远梦旗舰店</td>
								<td>13012345678</td>
								<td>zhangsan.001</td>
								<td>zhangsan.001</td>
								<td>112234967</td>
								<td><span class="list-status1">正常</span></td>
							</tr>
							<tr>
								<td>张三丰</td>
								<td>东莞远梦旗舰店</td>
								<td>13012345678</td>
								<td>zhangsan.001</td>
								<td>zhangsan.001</td>
								<td>112234967</td>
								<td><span class="list-status1">正常</span></td>
							</tr>
							<tr>
								<td>张三丰</td>
								<td>东莞远梦旗舰店</td>
								<td>13012345678</td>
								<td>zhangsan.001</td>
								<td>zhangsan.001</td>
								<td>112234967</td>
								<td><span class="list-status1">正常</span></td>
							</tr>
							<tr>
								<td>张三丰</td>
								<td>东莞远梦旗舰店</td>
								<td>13012345678</td>
								<td>zhangsan.001</td>
								<td>zhangsan.001</td>
								<td>112234967</td>
								<td><span class="list-status1">正常</span></td>
							</tr>
							<tr>
								<td>张三丰</td>
								<td>东莞远梦旗舰店</td>
								<td>13012345678</td>
								<td>zhangsan.001</td>
								<td>zhangsan.001</td>
								<td>112234967</td>
								<td><span class="list-status1">正常</span></td>
							</tr>
							<tr>
								<td>张三丰</td>
								<td>东莞远梦旗舰店</td>
								<td>13012345678</td>
								<td>zhangsan.001</td>
								<td>zhangsan.001</td>
								<td>112234967</td>
								<td><span class="list-status1">正常</span></td>
							</tr>
						</tbody>
					</table>
					<div class="paging">
						<ul>
							<li class="indexpage nopage"><span>首页</span></li>
							<li class="prevpage nopage"><span>上一页</span></li>
							<li class="current"><a href="#1">1</a></li>
							<li><a href="#2">2</a></li>
							<li><a href="#3">3</a></li>
							<li><a href="#4">4</a></li>
							<li><a href="#5">5</a></li>
							<li><a href="#6">6</a></li>
							<li><a href="#7">7</a></li>
							<li><a href="#8">8</a></li>
							<li><a href="#9">9</a></li>
							<li><a href="#10">10</a></li>
							<li class="ellpage"><span>...</span></li>
							<li class="nextpage"><a href="#">下一页</a></li>
							<li class="endpage"><a href="#">尾页</a></li>
						</ul>
					</div>
				</div>
			</div>
			<!-- End mainBox -->
		</div>
		<!-- End content -->
	</div>
	<div class="popBox inviteCode">
		<div class="titleBox">发送邀请码<span class="closeMe" title="关闭"></span></div>
		<table class="popTpl">
			<tr>
				<td width="32%" align="right" valign="top">姓名</td>
				<td><input type="text" class="ui-input userName"></td>
			</tr>
			<tr>
				<td align="right">手机号</td>
				<td><input type="text" class="ui-input phoneNum"></td>
			</tr>
			<tr>
				<td colspan="2" align="center"><input type="button" class="ui-btn1 okBtn" value="确 定"></td>
			</tr>
		</table>
	</div>
	<!-- popup -->
	<script src="./static/js/market.js"></script>
</body>
</html>