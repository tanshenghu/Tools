/*
	Description : 品牌商后台管理系统 - 分销商管理
	Author : TanShenghu
	Date : 2014-12-01
*/
var pagefn = {};

pagefn.inviteCode = function(){
	
	common.popupbox({
		
		hand : ".send-inviteCode",
		box : ".inviteCode",
		width : "400",
		height : "225"
		
	});
	
	// 确定 发送邀请码
	$('.inviteCode .okBtn').on('click', function(){
		
		var userName = $('.inviteCode .userName').val().trim(),
			phoneNum = $('.inviteCode .phoneNum').val().trim();
			
		var regexp = new RegExp(common.regexp.phone, 'g');
		
		if ( !userName.length ){
			
			alert( '请填写用户名！' );
			$('.inviteCode .userName').focus();
			
		}else if( !phoneNum.length ){
			
			alert( '请填写手机号码！' );
			$('.inviteCode .phoneNum').focus();
			
		}else if( ! regexp.test( phoneNum ) ){
			
			alert( '请填写正确有效的手机号码！' );
			$('.inviteCode .phoneNum').select();
			
		}else{
			
			// ajax后端交互了...
			
		}
		
	});
	
};

$(function(){
	
	// 发邀请码
	pagefn.inviteCode();
	
});