/*
	Description : 品牌商后台管理系统 - 首页
	Author : TanShenghu
	Date : 2014-12-01
*/
var pagefn = {};

// 首页，提现弹出层事件
pagefn.withdraw = function(){
	
	common.popupbox({
		
		hand : ".withdraw a",
		box : ".popBox.tx",
		width : "400",
		height : "265"
		
	});
	
	// 提现弹出层里面的 提现方式
	
	$('.selsortbox').on('mousedown', function( ev ){
		
		var ev = ev || event,
			thisObj = $(this);
		thisObj.find('.paysort').show();
		ev.stopPropagation();
		
	}).find('.paysort li').on('click', function( ){
		
		var newli = $(this).clone();
		
		$(this).parent().hide().closest('.selsortbox').find('ul').empty().append( newli );
		
	});
	
	$('body').on('mousedown', function(){
		$('.selsortbox .paysort').hide();
	});
	
	// 开始提现
	$('.popBox.tx .okBtn').on('click', function(){
		
		var moneyCount = $('.popBox.tx .moneyCount').val();
		if ( !moneyCount || isNaN( moneyCount ) ){
			
			alert('请输入有效的提现金额');
			
		}else{
			
			// 提现...
			
		}
		
	});
	
}

$(function(){
	
	// 提现弹出层
	pagefn.withdraw();
	
});