//define(function(require, exports, module){
/*
JS Document
◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇
◎ *@Description: javascript Obj 基类
◎ *@Author: 谭生虎       TanShenghu	TSH    
◎ *@Update: 2013-05-14
◎ *@Contact: ☎：13588428548		Email: tanshenghu@163.com	QQ：511568692
◎ *@AuthorNote: 请不要随便篡改文件内容。尊重他人劳动成果！谢谢...     谭生虎 注
◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇
*/
(function($){
	var tsh   = {},
		fnTsh = {};
	/*
		针对客户端信息捕获
	*/
	tsh.clientWidth = function(){return document.documentElement.clientWidth;};
	tsh.clientHeight = function(){return document.documentElement.clientHeight;};
	tsh.offsetHeight = function(){return document.documentElement.scrollHeight || document.body.scrollHeight;};
	tsh.offsetWidth = function(){return document.documentElement.scrollWidth || document.body.scrollWidth;};
	tsh.scrollHeight = function(){return document.documentElement.scrollTop || document.body.scrollTop;};
	tsh.scrollWidth = function(){return document.documentElement.scrollLeft || document.body.scrollLeft;};
	tsh.Resolution = function( Options ){																	/* 捕获客户端分辨率 参数说明：传入x捕获宽，传入y捕获高，否则捕获宽×高 */
		var X = window.screen.width,Y = window.screen.height;
		return Options=='x' ? X : Options=='y' ? Y : X+'×'+Y;
	};
	tsh.checkIE = (!+[1,]);
	tsh.browserMsg = window.navigator.userAgent.toLowerCase();
	tsh.IEDocMode = document.documentMode;
	tsh.usebrowser = tsh.browserMsg.match(/msie 6./img) ? 'IE6' : tsh.browserMsg.match(/msie 7./img) ? 'IE7': tsh.browserMsg.match(/msie 8./img) ? 'IE8' : tsh.browserMsg.match(/msie 9./img) ? 'IE9' : tsh.browserMsg.match(/msie 10./img) ? 'IE10' : tsh.browserMsg.match(/firefox/img) ? 'firefox' : 'webkit';
	tsh.setcookies = function(key, val){
		var saveCookieStr='',setOutTime=arguments[2],saveDay;
		saveCookieStr = key+'='+escape(val);
		if (setOutTime!=undefined)
		{
			setOutTime = parseFloat(setOutTime);
			saveDay = new Date();
			saveDay.setDate(saveDay.getDate()+setOutTime);
			saveCookieStr = saveCookieStr + '; expires='+saveDay.toGMTString();
		}
		document.cookie = saveCookieStr+'; path=/';
	};
	tsh.getcookies = function( key ){
		var CookStr = document.cookie;
		CookArr = CookStr.split('; ');
		for(var i in CookArr)
		{
			if (CookArr[i].split('=')[0]==key)
			{
				return unescape(CookArr[i].split('=')[1]);
			}
		}
	};
	tsh.delcookies = function( key ){
		var keyVal = '',saveDay;
		saveDay = new Date('1970/01/05');
		saveDay.setDate(saveDay.getDate());
		document.cookie = key+'='+keyVal+'; expires='+saveDay.toGMTString()+'; path=/';
	};

	/*
		 log 方法
	*/
	tsh.log = function( style, str ){
		if ( !str ){
			str = style;
			style = undefined;
		}
		if ( console && console.log )
			console.log( "%c%s", (style||''), str );
	};
	/* 
		所有方法的备注说明，将更好的让开发者熟练运用所有方法
	*/
	tsh.remark = function( key ){
		
		var key = key ? eval('this.'+key) : this;
		var result = '',
			length = 0,
			fnlen  = 0;
		
		key || this.log( '该对象不存在！' );
		for(var i in key){
			
			length++;
			if( typeof key[i] === 'function' ){
				fnlen++;
				this.log( 'color:red', 'function => ' + i );
			}else if( isNaN( key[i] ) ){
				this.log( 'color:green', 'number => ' + i );
			}else{
				this.log( typeof key[i] + ' => ' + i );
			}
			
		}
		
		this.log( '共查找到 '+length+' 个对象，其中方法对象 '+fnlen+' 个' );
		
	};
	/*
		方法参数调用 示例
	*/
	tsh.remark.demo = function( key ){
		if ( !key ) return;

		$.getJSON('http://www.tanshenghu.com/code/tsh_js.php?callback=?', 'key='+key, function(data){
			data = data.toString();
			tsh.log( data );
		});
		
	};
	/*
		图片数字
	*/
	tsh.picNum = function(num, path){
		var picStr = '';
		if ( num && path && !isNaN(num) ){
			num = num+'';
			var NumArr = num.split('');
			for(var i in NumArr)
			{
				picStr+='<img src="'+path+NumArr[i]+'.gif" class="middle" />';
			}
		}
		return picStr;
	};

	/*  获取form表单字段 提交至后端 parameter
	
		参数格式{form:"#form", selector:".myInput", way:true, Encode:escape}
		说明：form是大的容器可是以form,div任意非输入框元素
			  selector特殊筛选元素，可选或者反选都可以
			  way是配合selector特殊筛选的参数，布尔值默认为true
			  Encode是编码方法。可传入常用的三种编码中的任意一种都行
	*/
	tsh.Get_form_param = function( param ){
		if ( !(param instanceof Object) ) this.log( 'parameter '+param+' error' );

			var form = checkJqObject( param.form ),
				selectEle = param.selector ? checkJqObject( param.selector ) : false,
				way = 'way' in param ? param.way : true;

			var	selector = null,
				resultParam = {};

			function checkJqObject( obj ){
				var newObj = obj;
				if ( !(obj instanceof jQuery) ){
					newObj = $(newObj);
				}
				return newObj;
			};
			var FormatHtml = function( val ){
				return $('<div/>').text( val ).html();
			};
			var Encode  = function( value ){

				if ( param.Encode ){
					value = param.Encode( value );
				}
				return value;
			};

			if ( selectEle && way ){
				selector = form.find( selectEle );
			}else if ( selectEle && (!way) ){
				selector = form.find('input[name],textarea[name]').not( selectEle );
			}else{
				selector = form.find('input[name],textarea[name],select[name]');
			}

			selector.each(function(eid, ele){
				var thisObj = $(ele),
					iName   = thisObj.attr('name'),
					type    = thisObj.attr('type') && thisObj.attr('type').toLowerCase();
		
				if ( iName && type && type==='radio' ){

					if ( thisObj.prop('checked') ){
						resultParam[iName] = FormatHtml( Encode( thisObj.val() ) );
					}

				}else if( iName && type && type==='checkbox' ){
					
					if ( thisObj.prop('checked') ){
						
						if ( resultParam[iName] ){
							resultParam[iName].push( FormatHtml( Encode( thisObj.val() ) ) );
						}else{
							var itemArr = [ FormatHtml( Encode( thisObj.val() ) ) ];
							resultParam[iName] = itemArr;
						}
						
					}

				}else if ( iName ){
				
					resultParam[iName] = FormatHtml( Encode( thisObj.val() ) );
					
				}

			});

			if( param.split ){
				for(var i in resultParam){
					if( resultParam[i] instanceof Array ){
						resultParam[i] = resultParam[i].join( param.split );
					}
				}
			};


			return resultParam;
		
	};
	/*
		 考虑到 如：兴趣、爱好之类 checkbox同name属性，最终需要组合成数组对象
	*/
	tsh.Get_form_param.Get_checkbox = function(form, checkName){
			var resultObj = {},
				getVal    = [],
				decoll    = arguments[2];

			form = $( form );

			form.find('[name="'+checkName+'"]').each(function(i, ele){
				var thisObj = $(ele),
					type    = thisObj.attr('type') && thisObj.attr('type').toLowerCase();

				if ( type && (type === 'radio' || type === 'checkbox') ){
					if ( thisObj.prop('checked') ){
						getVal.push( $(ele).val() );
					}		
				}else{
					if ( thisObj.val() ){
						getVal.push( $(ele).val() );
					}				
				}
			});

			if ( decoll ){
				resultObj[checkName] = getVal.join( decoll );
			}else{
				resultObj[checkName] = getVal;
			}
			
			return resultObj;
	};
	// 对form表单获取数据的扩展，主要是对tr行获取数据的扩展
	tsh.Get_form_param.getLineVals = function( trs ){
		trs = $( trs );
		var result = [];
		trs.each(function(){
			var iObj = {};

			$(this).find('[name]').each(function(i, ele){
				var elent = $(ele),
				    nodeName = elent.prop('nodeName').toLowerCase();
				if ( nodeName == 'input' || nodeName == 'textarea' || nodeName == 'select' ){
					iObj[ elent.attr('name') ] = elent.val();
				}else{
					iObj[ elent.attr('name') ] = elent.text();
				}
			});
			
			result.push( iObj );
			
		});
		
		return result;
		
	};
	// 删除tr行数据
	tsh.removeLine = function( This ){
		This = $( This );
		var pobj = This.closest('tr');
		pobj.remove();
	};
	// 添加行数据
	tsh.addNewLine = function( tplTab, tarTab ){
		tplTab = $( tplTab );
		tarTab = $( tarTab );
		var lastTr;
		if ( tplTab.prop('nodeName').toLowerCase()==='script' ){
			lastTr = $( tplTab.html() );
		}else{
			lastTr = tplTab.find('tbody tr').last();
		}
		var newTr = lastTr.clone( true );
		newTr = newTr.not('.noEmpty');
		newTr.find(':text,textarea').val('');
		newTr.find('.cival').empty();
		tarTab.find('tbody').append( newTr );
	};
	/*
		在jq中dom对象下挂接
	*/
	/*
		节点操作
	*/
	tsh.getComputedStyle = function( ele, curCN ){
		var This = ele.nodeName ? ele : ele.get(0);
		return This.currentStyle ? This.currentStyle[curCN] : getComputedStyle(This,null)[curCN];
	};
	tsh.allHeight = function( repeat ){
		var setHval = arguments[1],maxH=0;
		if ( !setHval )
		{
			this.each(function(i, ele){

				if ( repeat ){$(ele).css('height','auto');}/* 初始化高度之后有利于重新第再次计算 */
				if ($(ele).height()>maxH)
				{
					maxH = $(ele).height();
				}
		
			});
			this.height(maxH);
		}else{
			setHval = parseFloat(setHval);
			$(arrayObj.join(',')).height(setHval);
		}
	};
	tsh.checkall = function(hand, checkbox){
		
		hand = $(hand),
		checkbox = $(checkbox);
		
		var elesort = hand.prop('nodeName') && hand.prop('nodeName').toLowerCase();
		
		var evt = ( elesort == 'input' ) ? 'change' : 'click';

		hand.on(evt, function(){
			
			if ( elesort == 'input' ){
				
				if ( hand.prop('checked') ){
					checkbox.prop('checked', true);
				}else{
					checkbox.prop('checked', false);
				}
				
			}else{
				
				if ( hand.text()=='\u5168\u9009' ){
					checkbox.prop('checked', true);
					hand.text('\u4E0D\u5168\u9009')
				}else{
					checkbox.prop('checked', false);
					hand.text('\u5168\u9009')
				}
				
				
			}
			
		});
		
	};
	
	
	// 接口 绑定至jquery下面
	$.tsh = tsh;
	
	
	
	
})(jQuery)


/*
	对一些原生方法的扩展
*/
if( !''.trim ){
	String.prototype.trim = function(){
		return this.replace(/^\s+|\s+$/mg,'');
	}
};

String.prototype.rtrim = function( delStr ){
	// 没有想到很好的正则，先分开写得土了点
	var resultStr = '';
	if ( delStr ){
		var I = this.lastIndexOf( delStr );
		resultStr = this.substring(0, I <0 ? this.length : I) + (I <0 ? '' : this.substring( I+1 ));
	}else{
		resultStr = this.replace(/.$/mg,'');
	}
	
	return resultStr;
	
};
String.prototype.ltrim = function( delStr ){
	var resultStr = '';
	if ( delStr ){
		var I = this.indexOf( delStr );
		resultStr = this.substring(0, I <0 ? this.length : I) + (I <0 ? '' : this.substring( I+1 ));
	}else{
		resultStr = this.replace(/^./mg,'');
	}
	
	return resultStr;
};

Array.prototype.delVal = function( val, repeat ){
	var one = false;
	for(var i in this){
		if ( this[i]===val && !one ){
			this.splice(i, 1);
			if ( !repeat ){
				one = true;
			}
		}
	}
	return this;
};

Array.prototype.clearRepeat = function(){
	var item = {}, result = [];
	for(var i=0,l=this.length; i<l; i++){
		var m = (typeof this[i])+this[i];
		if ( item[m] === undefined ){
			result.push( this[i] );
			item[m] = 'yes';
		}
	}
	
	return result;
};




var common = {};

//  正则
common.regexp = {};
common.regexp.tel = '^(0\d{2,3}-)?[1-9]\d{6,7}(-\d{1,4})?$';
common.regexp.phone = '^1[3|5|7|8|][0-9]{9}$';
// 选项卡切换
common.checkTab = function(hand, box){
	var callback = arguments[2];
	$(hand).bind('click', function(){
		var thisObj = $(this),
			Index 	= thisObj.index(hand);
		thisObj.addClass('active').siblings(hand).removeClass('active');	
		$(box).eq(Index).show().siblings(box).hide();
		if( typeof callback === 'function' ){
			callback.apply(this,[]);
		};	
	});
};
// 取url参数
common.UrlPara = function(parText){
		var url = arguments[1] || document.URL;		/* 获取参数方法，该方法共提供两个参数，第一个必选参数。第二个可选参数具体的URL地址 */
		var parameter = url.substring(url.lastIndexOf('?')+1);
		var aPar = parameter.split('&');
		//var result = {};
		for (var i=0; i<aPar.length; i++)
		{
			if (aPar[i].split('=')[0]==parText)
			{
				return aPar[i].split('=')[1];
			}
		}
		return false;
};

// 简单的写一个浮层效果
common.popupbox = function( param ){
	var hand= $( param.hand ),
		evet= param.evet || 'click',
		delegateEle = param.delegateEle,
		box = $( param.box ),
		cover = param.cover,
		CW  = 0,
		CH  = 0,
		boxW= parseInt( param.width ),
		boxH= parseInt( param.height ),
		sclT= 0,
		callback = param.callback;

	if ( !box.length ){
		console.log( "error:not "+param.box );
		return;
	}
	// 是否外层判断并处理
	if ( box.parent().prop('nodeName').toLowerCase()!='body' ){
		$('body').append( box );
	}

	if ( !(param.width) && !(param.height) ){
		box.css('display','inline');
		boxW = box.width();
		boxH = box.height();
	}

	var bgDiv = $('#coverPop').length ? $('#coverPop') : $('<div id="coverPop"></div>');

	var posFn = function(){
		CW  = document.documentElement.clientWidth;
		CH  = document.documentElement.clientHeight;
		sclT= $(document).scrollTop() || 0;
	
		var left = ( ( CW - boxW )*0.5 < 0 ) ? 0 : ( ( CW - boxW )*0.5 > (CW-boxW) ) ? CW-boxW : ( CW - boxW )*0.5;
		var top = ( ( CH - boxH )*0.5 < 0 ) ? 0 : ( ( CH - boxH )*0.5 > (CH-boxH) ) ? CH-boxH : ( CH - boxH )*0.5;

		var css = {
			"position":"absolute",
			"z-index":"1000",
			"display":"none",
			"left":left,
			"background-color":"white",
			"top":top+sclT
		};

		var DH = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
		bgDiv.css({"position":"absolute","z-index":"998","left":"0","top":"0","width":"100%","display":"none","background":"black","opacity":"0.5","height":DH});

		return css;
	};

	var css = posFn();

	if ( param.width && param.height ){
		css.height = param.height;
		css.width = param.width;
	}else{
		css.height = 'auto';
		css.width = 'auto';
	}

		
	box.css( css );
	cover = ( typeof cover == 'undefined' ) ? true : cover;
	if ( cover ){
		box.before( bgDiv );
	}

	if ( evet === 'delegate' ){
		hand.delegate(delegateEle,'click', function(){
			var DH    = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight),
				thisObj = $(this);
			box.css( posFn() );
			bgDiv.height( DH ).fadeIn();
			box.fadeIn();
			if ( typeof callback === 'function' ){
				callback.apply(this, [thisObj,box]);
			}
		});
		
	}else{
		hand.on('click', function(){
			var DH    = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
			box.css( posFn() );
			bgDiv.height( DH ).fadeIn();
			box.fadeIn();
			if ( typeof callback === 'function' ){
				callback.apply(this, [$(this),box]);
			}
		});
	}
	

	box.find('.closeMe').on('click', function(){
		if ( cover ){
			bgDiv.fadeOut('fast');
		}
		box.fadeOut('fast');
	});
};

// 清空节点内容操作
common.emptyele = function( box ){
	var Box   = $(box),
		deEle = arguments[1] || '.jq-empty';

	Box.find( deEle ).each(function(i, ele){
		var curEle = $(ele);
		if( curEle.prop('nodeName').toLowerCase()==='input' || curEle.prop('nodeName').toLowerCase()==='textarea' ){
			curEle.val('');
		}else if( curEle.prop('nodeName').toLowerCase()==='select' ){
			curEle.find(':selected').prop('selected', false);
		}else{
			curEle.html('');
		};

	});
};

// select 下拉框
common.dropDown = function(){
		var thisdropDown = $('.dropdownbox');
		
		$('.dropdownbox').on('mousedown', function( ev ){
			var ev = ev || event,
				thisObj = $(this);
			$('.dropdownbox').not( thisObj ).find('.downcontent').hide();
			
			if ( !thisObj.find('.downcontent a').length ){
				return;
			}
			
			thisObj.find('.downcontent').slideDown('fast');
			
			thisdropDown = thisObj;
			
			ev.stopPropagation();
		}).find('.downcontent').on('click','a',function( ev ){
			var thisObj = $(this),
				dropdownbox = thisObj.closest('.dropdownbox'),
				cinput = dropdownbox.children('.cinput');
			
			var callfn = dropdownbox.data( 'dropdown' );
			
			if ( cinput.prop('nodeName').toLowerCase() === 'input' ){
				cinput.val( thisObj.html() ).attr('key', thisObj.attr('key') || '' );
			}else{
				cinput.text( thisObj.html() ).attr('key', thisObj.attr('key') || '' );
			}
			thisObj.parent().slideUp('fast');
			
			if ( callfn && callfn.callback && typeof callfn.callback == 'function' ){
				callfn.callback.apply( this,[] );
			}
			
		}).prevAll(':text').prop('readonly', true);
		
		$(document).on('mousedown', function(){
			$('.dropdownbox .downcontent').hide();
		});
		
		//return thisdropDown;
		
	};
	

// 搜索字段清空
common.formInputEmpty = function(){
	
	$('.inputEmpty').on('click', function(){
		common.emptyele('.searchInfo', '.ui-input,select');
	});
	
};
// 自定义的一些分享
common.share = function( shares ){
	
	var shareInt = function( param ){
		var name 	   = param.name,
			title      = param.title || '',
			url        = param.url || document.URL,
			pic        = param.pic || '',
			ralateUid  = param.ralateUid || '',
			description=param.description || '';
		
		
		var shareObj = {
			'weibo' : 'http://service.weibo.com/share/share.php?title='+title+'&url='+url+'&source=bookmark&appkey=webpage&pic='+pic+'&ralateUid='+ralateUid,
			'renren' : 'http://widget.renren.com/dialog/share?resourceUrl='+url+'&srcUrl='+url+'&title='+title+'&pic='+pic+'&description='+description,
			'qq' : 'http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url='+url+'&title='+title+'&pics='+pic+'&summary='+description,
			'txweibo' : 'http://share.v.t.qq.com/index.php?c=share&a=index&title='+title+'&url='+url+'&appkey=webpage&site=&pic='+pic
		};
		
		$.extend(shareObj, shares);
		
		
		return shareObj[name] || 'javascript:;';
	
	};
	
	$('.jq-share').each(function(i, ele){
		
		var thisObj = $(ele),
			content = thisObj.data('content');
		
		if ( content ){
			
			var newUrl = shareInt( content );
			thisObj.attr('href', newUrl);
			if ( newUrl!='javascript:;' ){
				thisObj.attr('target','_blank');
			}
			
		}
		
		
	});
	
	
};

// 后台左侧导航选中
common.currentMenu = function( index ){
		
		index = ( typeof index != 'number' ) ? parseInt( index ) : index;
		if ( typeof index != 'number' ) return false;
		
		$('#leftMenu li').eq( index ).addClass('current').siblings('li').removeClass('current');
		
};

// placeholder
common.placeholder = function(){
	
	var isie = ~~$.tsh.usebrowser.replace('IE','');
	if( isie>0 && ( $.tsh.IEDocMode<10 || $.tsh.IEDocMode==='undefined' ) ){
		$(':text[placeholder]').each(function(ele, i){
			var thisObj = $(this),
				label = $('<label class="placeholder">'+thisObj.attr('placeholder')+'</label>');
			
			thisObj.parent().css('position','relative')
			thisObj.after( label );
			
			label.on('click', function(){
				$(this).hide().prev(':text').focus();
			});
			thisObj.on('focus', function(){
				if( $(this).next('label:visible') ){
					label.hide();
				}
				
			}).on('blur', function(){
				if( !$(this).val().trim() ){
					label.show();
				}
			});
			
		});
	}
	
};
// 左侧导航 选中处理
common.dealMenu = function( config, menus ){
	var pathname = location.pathname,
		menuele  = $(menus);
	for( var i=0,l=config.length; i<l; i++ ){
		var reg = pathname.match( config[i].pageName, 'g' );
		if ( reg ){
			menuele.find('.current').removeClass('current');
			menuele.find('[pagename="'+config[i].menu+'"]').addClass( 'current' );
		}
	}
};


// 分页 grid 参数
common.gridParam = {
	'jsonformat' : {content:"content",count:"count",list:"list",pageIndex:"id"},
	'sUrl':'',
	'columnDefs':[],
   'oRequestParam':{},
   'bPaginate':true,
   'nPageNo':1,
   'nPageSize':10
};

// 上传参数
common.uploadParam = {
	height : 75,
	width : 75,
	'swf' : '../system/static/flash/uploadify.swf',
	'formData' : {},
	'uploader': '../product/uploadFile.do;jsessionid='+getSessionId(), 
	'folder': 'upload',
	'queueID': 'fileQueue',
	'auto': true,
	'buttonText':'+添加图片',
	'sizeLimit':'2097152',
	'fileTypeDesc': '支持的格式：',
    'fileTypeExts': '*.jpg;*.jpge;*.gif;*.bmp;*.png',
	'multi': false,
	'onFallback': function () {
        alert("您未安装FLASH控件，无法上传图片！请安装FLASH控件后再试。");
    },
	'onSelectError': function (file, errorCode, errorMsg){
		alert(errorMsg);
	},
    onUploadSuccess : function(fileObj, data, response){}
};


$(function(){
	
	// 页面中所有下拉框
	common.dropDown();
	// 搜索条件 字段清空
	common.formInputEmpty();
	// 左侧导航选中
	//common.currentMenu( window.currentMenuId || 0 );
	// placeholder
	common.placeholder();
	
});


//});

// 文件上传取cookies
function getSessionId(){
	var c_name = 'JSESSIONID';
	if(document.cookie.length>0){
		c_start=document.cookie.indexOf(c_name + "=");
		if(c_start!=-1){ 
			c_start=c_start + c_name.length+1;
			c_end=document.cookie.indexOf(";",c_start);
			if(c_end==-1) c_end=document.cookie.length;
			return unescape(document.cookie.substring(c_start,c_end));
		}
	}
}
