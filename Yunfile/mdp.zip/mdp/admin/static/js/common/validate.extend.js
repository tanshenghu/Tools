jQuery.validator.addMethod("phone", function(value, element) {   
    var tel = /^1[3|5|7|8|][0-9]{9}$/;
    return this.optional(element) || (tel.test(value));
}, "请填写正确的手机号码");
jQuery.validator.addMethod("tel", function(value, element) {   
    var tel = /^(0\d{2,3}-)?[1-9]\d{6,7}(-\d{1,4})?$/;
    return this.optional(element) || (tel.test(value));
}, "请填写正确的电话号码");

jQuery.validator.addMethod("personID", function(value, element) {   
    var tel = /^(0\d{2,3}-)?[1-9]\d{6,7}(-\d{1,4})?$/;
    return this.optional(element) || (tel.test(value));
}, "请填写正确的电话号码");