/*
	Description : 品牌商后台管理系统
	Author : TanShenghu
	Date : 2014-12-01
*/

var pagemain = {
	
	SYS_TipPopBox : function(){
		var SYS_errorBox = $('<div id="SYS-TipPopBox" class="popBox"><h3 class="titleBox"><label></label><span class="closeMe" title="关闭"></span></h3><table><tr><th><i></i></th><td><div class="msg"></div></td></tr><tr><td colspan="2"><p class="btnbox"><input type="button" value="确 定" class="ui-btn1 OKBtn"><input type="button" value="取 消" class="ui-btn2 cancelBtn"></p></td></tr></table><input type="hidden" class="SYSTipPop-showBtn"></div>');
		$('body').append( SYS_errorBox );
		
		var callfnParam = {},
			msgIcoArr = ['Err','OK','confirm','warning','warning2'];
		
		common.popupbox({
		
			hand : SYS_errorBox.find('.SYSTipPop-showBtn'),
			box : SYS_errorBox,
			cover : false,
			width : "400",
			height : "200",
			callback : function(hand, box){
				box.find('.titleBox label').text( callfnParam.title || '' );
				box.find('i').attr('class', msgIcoArr[ callfnParam.msgIco ] );
				box.find('.msg').text( callfnParam.msg );
				if ( typeof callfnParam.callback === 'function' ){
					callfnParam.callback.apply( this, [box] );
				}
			}
			
		});
		SYS_errorBox.find('.btnbox .cancelBtn').on('click', function(){
			SYS_errorBox.find('.closeMe').trigger('click');
		});
		
		this.showPopTip = function( options ){
			callfnParam = options;
			SYS_errorBox.find('.SYSTipPop-showBtn').trigger('click');
			
		};
		
	}
	
};


$(function(){
	
	// 选中对应左侧导航
	common.dealMenu(pageConfig(),"#leftMenu ul");
	
	// 追加系统消息 提示层
	pagemain.SYS_TipPopBox();
	/*
		参数说明：
		msgIco : 传入整型数字, 0错误、1正常、2是否确定框、3橙色警告、4蓝色警告
		msg : 输出string类型，消息内容
		title : 提示的title文案
		callback : 回调方法
	*/
	/*pagemain.showPopTip({
		msgIco:1,
		msg:'恭喜您，您已经转帐成功！',
		title:"系统温馨提示",
		callback:function( box ){
			
			
		}
	});*/
	
	
	
});

function pageConfig(){
	/*
		后台 左侧导航选中，页面配置：
		pageName一定要与当前页面名一致, eg: xxx.do, xxx.vm, xxx.htm
		menu 与左侧菜单标签上对应的pagename属性的值
	*/
	window.menuPageNameId = window.menuPageNameId || {};
	return [
		{
			"pageName" : "index",
			"menu" : menuPageNameId["index"]
		},
		{
			"pageName" : "shopManage",
			"menu" : menuPageNameId["shopManage"]
		},
		{
			"pageName" : "shopListView",
			"menu" : menuPageNameId["shopListView"]
		},
		{
			"pageName" : "share",
			"menu" : menuPageNameId["share"]
		},
		{
			"pageName" : "market",
			"menu" : menuPageNameId["market"]
		},
		{
			"pageName" : "permissionsManager",
			"menu" : menuPageNameId["permissionsManager"]
		},
		{
			"pageName" : "order",
			"menu" : menuPageNameId["order"]
		},
		{
			"pageName" : "bindBankCard",
			"menu" : menuPageNameId["bindBankCard"]
		}
	];

};