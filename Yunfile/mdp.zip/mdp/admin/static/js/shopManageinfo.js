/*
	Description : 品牌商后台管理系统 - 店铺管理 - 管理
	Author : TanShenghu
	Date : 2014-12-01
*/

var pagefn = {};

pagefn.checkshop = function(){
	common.popupbox({
		
		hand : ".checkshopBtn",
		box : ".checkshopPop",
		width : "580",
		height : "550"
		
	});
	
	
	// 全选 操作
	
	$.tsh.checkall('.checkshopPop .checkAll', '.checkshopPop :checkbox');
	
};

// 挑选商品 浮层 里面所有勾选过的值
pagefn.getCheckVal = function(){
	var valName = ['checkbox','name','price','count'],
		result = [];
	$('.popBox tbody :checked').each(function(i, ele){
		var iobj = {};
		var tr = $(this).closest('tr');
		tr.find('td').each(function(j, emt){
			
			if ( j>0 ){
				iobj[ valName[j] ] = $(emt).text();
			}
			
		});
		result.push( iobj );
		
	});
	
	return result;
};

$(function(){
	
	// 挑选商品
	pagefn.checkshop();
	
	$('.popBox .ui-btn1').on('click', function(){
		alert( JSON.stringify( getVal() ) );
	});
	
});