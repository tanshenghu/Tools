/*
	Description : 品牌商后台管理系统 - 店铺管理 - 分享
	Author : TanShenghu
	Date : 2014-12-01
*/

var pagefn = {};

pagefn.sharePop = function(){
	
	common.popupbox({
		
		hand : ".addnewShare",
		box : ".sharPop",
		width : "580",
		height : "245"
		
	});
	
};

$(function(){
	
	// 新增 分享
	pagefn.sharePop();
	// 分享
	common.share();
	
});