/*
	Description : 品牌商后台管理系统 - 订单管理 - 新增商品
	Author : TanShenghu
	Date : 2014-12-01
*/

var pagefn = {};

// 下拉联动
pagefn.createOption = function( arr ){
	var newoption = '';
	$.each(arr, function(key, val){
		newoption += '<option>'+val+'</option>';
	});
	return newoption;
};
pagefn.select_cls = function(){
	
	$('.jq-cls1').on('change', function(){
		var key = $(this).val();
		
		// 联动的小示例做做样子，后端要写接口调ajax...
		$('.jq-cls2').html( pagefn.createOption(["选项一","选项二","选项三"]) );
		/*
		$.getjSON('', {}, function(data){
			$('.jq-cls2').html( pagefn.createOption(data) );
		});
		*/
	});
	
};


// 商品规格
pagefn.rank = function(){
	
	var callfn = {};
	callfn.callback = function(){
		var aObj = $(this);
		
		$('.addBtnBox').addClass('undis');
		
		if ( aObj.attr('key')!='0' ){
			$('.addBtnBox').removeClass('undis');
		}
	};
	
	$('.addrank .dropdownbox').data('dropdown', callfn);
	
	// 添加
	$('.addrank .addBtn').on('click', function(){
		var selele = $('.addrank .dropdownbox .cinput'),
			numval = $('.addrank .addListInput').val();
		if ( selele.attr('key')!='0' ){
			var b = false;
			/*
			$('.addrank .existlist option').each(function(i, ele){
				if ( $(ele).html()==selele.html() ){
					b = true;
				}
			});
			if ( !b )
				$('.addrank .existlist').append( '<option>'+selele.html()+'</option>' );
			*/
			$('.kctab thead').each(function(i, ele){
				if ( $(ele).find('th').first().html()==selele.html() ){
					b = true;
				}
			});
			if ( !b ){
				if ( $('.kctab tbody').length ){
					$('.kctab tbody').append( '<tr><td><div class="Ssize">'+numval+'</div></td><td><input type="text" class="ui-input shoperId"></td><td><input type="text" class="ui-input shopCount"></td><td><input type="text" class="ui-input market"></td><td><input type="text" class="ui-input propose"></td><td><input type="text" class="ui-input agent"></td></tr>' );
				}else{
					$('.kctab tfoot').before( '<tbody><tr><td><div class="Ssize">'+numval+'</div></td><td><input type="text" class="ui-input shoperId"></td><td><input type="text" class="ui-input shopCount"></td><td><input type="text" class="ui-input market"></td><td><input type="text" class="ui-input propose"></td><td><input type="text" class="ui-input agent"></td></tr></tbody>' );
				}	
			}
			
		}
	});
	
	// 总库存
	var totalCount = function(){
		var count = 0;
		$('.kctab .shopCount').each(function(i, ele){
			ele = $(ele);
			var num = ele.val() || 0;
			if ( isNaN( num ) ){
				ele.val('');
				num = 0;
			}
			num = parseInt( num );
			ele.val( num );
			count += num;
		});
		return count;
	};
	
	$('.ifieldbox .kccount').val( totalCount() );
	$('.kctab').on('keyup', '.shopCount', function(){
		$('.ifieldbox .kccount').val( totalCount() );
	});
	
	// 设置价格，库存
	$('.setprice .OKBtn').on('click', function(){
		var num = $(this).prev(':text').val();
		if ( isNaN( num ) ) return false;
		$('.kctab .propose').val( num );
		
	});
	$('.setstock .OKBtn').on('click', function(){
		var num = $(this).prev(':text').val();
		if ( isNaN( num ) ) return false;
		$('.kctab .shopCount').val( num );
		$('.ifieldbox .kccount').val( totalCount() );
	});
	
};

// 文件上传
pagefn.upload = function(){
	
	var param = common.uploadParam;
	param.swf = 'static/flash/uploadify.swf';
	param.onUploadSuccess = function(fileObj, data, response){
	    $( '#uploader' ).find('.uploadify-button').empty().append( $('<img class="egPic" src="'+data.src+'">') );
	};
	
	$( '#uploader' ).uploadify( param );
	
};

// 编辑器 
var editor;
KindEditor.ready(function(K) {
	editor = K.create('textarea[name="content"]', {
		allowFileManager : true,
		width:'780',
		height : '250'
	});
});

// 提交
pagefn.submit = function(){
	
	// 日历控件
	$('.Wdate').on('click', function(){
		WdatePicker({
			minDate:'%y-%M-%d',
			dateFmt:'yyyy-MM-dd',
			readOnly : true
		});
	});
	
	// 表单的验证规则 我就写了前面几个input、select做例子，根据需求哪些是必填写项、必选项等照着例子自己添加吧。
	var form = $('.myform').validate({
		rules : {
			shopCls1 : {
				required : true
			},shopTitle : {
				required : true
			},
			shopCode : {
				required : true
			}
		},messages : {
			shopCls1 : {
				required : "请选择商品类目"
			},shopTitle : {
				required : "请填写商品标题，限30个字符以内"
			},shopCode : {
				required : "请填写商家编码"
			}
		},errorPlacement: function(error, element) {
    		if ( element.is(':radio') ){
    			$(element).parent().append( error );
    		}else if( element.is(':checkbox') ){
    			$(element).parent().append( error );
    		}else if( element.hasClass('parentshowerr') ){
    			$(element).parent().append( error );
    		}else{
    			$(element).after( error );
    		}
		},submitHandler : function( frm ){
			alert('通过验证，准备提交后台！');
		}
	});
	
};


$(function(){
	
	pagefn.upload();
	
	pagefn.select_cls();
	
	pagefn.rank();
	
	pagefn.submit();
	
});