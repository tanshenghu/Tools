/*
	Description : 品牌商后台管理系统 - 分销商管理
	Author : TanShenghu
	Date : 2014-12-01
*/
var pagefn = {};

// 发货 弹出层
pagefn.sendPop = function(){
	common.popupbox({
		
		hand : ".sendPopBtn",
		box : ".sendPop",
		width : "400",
		height : "265"
		
	});
};

$(function(){
	
	// 发货 弹出层
	pagefn.sendPop();
	
});