/*
	Description : 品牌商后台管理系统 - 店铺管理
	Author : TanShenghu
	Date : 2014-12-01
*/

var pagefn = {};

// 分页列表
pagefn.grid = function(){
	
	// 列表 操作
	var handle = function(rowIndex,colIndex,colDef,rowData){
		
		var htmlStr = '';
		htmlStr = '<a href="shopManageinfo.php">管理</a> <a href="#">注销</a>';		
		return htmlStr;
		
		
	};
	// 列表 状态
	var status = function(rowIndex,colIndex,colDef,rowData){
		
		var htmlStr = '';
		switch( rowData.status ){
			case 1 : htmlStr+='<span class="list-status1">正常</span>';break;
			case 2 : htmlStr+='<span class="list-status2">异常</span>';break;
			case 3 : htmlStr+='<span class="list-status3">注销</span>';break;
		}

		return htmlStr;
		
	};
	
	
	var params = common.gridParam;
	
	params.sUrl = '../json/grid.txt';
	params.jsonformat.content = 'content';
	
	params.columnDefs = [

	       {'type':'string','name':'shopname'},
	       {'type':'string','name':'classname'},
	       {'type':'string','name':'name'},
	       {'type':'string','name':'phone'},
	       {'type':'callback','render':status},
	       {'type':'callback',"render": handle}
	       
	   ];
	   
	params.nPageSize = 2;
	 
	var grid = $('.grid').easygrid( params );
	
	$('.searchInfo .searchBtn').on('click', function(){
		
		var option = $.tsh.Get_form_param({form:".searchInfo"});
		grid.reload( option );
		
	});
	
};


$(function(){
	
	// 分页
	pagefn.grid();
	
});