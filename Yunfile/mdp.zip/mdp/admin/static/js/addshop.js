/*
	Description : 品牌商后台管理系统 - 店铺管理 - 增加新店
	Author : TanShenghu
	Date : 2014-12-01
*/
var pagefn = {};

// 文件上传
pagefn.upload = function(){
	
	$('#UploadFile').uploadify({
		height        : 110,
		width         : 100,
		'swf' : 'static/flash/uploadify.swf',
		'formData' : {},
		'uploader': '/index.json', 
		'folder': 'upload',
		'queueID': 'fileQueue',
		'auto': true,
		'buttonText':'点击上传',
		'sizeLimit':'2097152',
		'fileTypeDesc': '支持的格式：',
        'fileTypeExts': '*.jpg;*.jpge;*.gif;*.png',
		'multi': false,
		'onFallback': function () {
            alert("您未安装FLASH控件，无法上传图片！请安装FLASH控件后再试。");
        },
		'onSelectError': function (file, errorCode, errorMsg){
			alert(errorMsg);
		},
        onUploadSuccess : function(fileObj, data, response){
        	
        	$('#UploadFile').hide().after( $('<img class="egPic" src="'+data.src+'">') );

        }
	});
	
};

pagefn.subform = function(){
	
	$('.addshopfield .subBtn').on('click', function(){
		
		var shopName = $('.addshopfield .shopName'),
			brandName= $('.addshopfield .brandName');
		
		$('.addshopfield .formTip').remove();
		
		if ( !shopName.val().trim() ){
	
			shopName.focus().after( $('<p class="formTip">请填写店铺名称</p>') );
		
		}else if( !brandName.val().trim() ){
			
			brandName.focus().after( $('<p class="formTip">请填写品牌名称</p>') );
			
		}else{
			
			var param = $.tsh.Get_form_param({
				form : '.addshopfield'
			});
			
			/*
				 ajax提交后端 param为所获取字段
				 $.post('xxx.json', param, function( data ){ });
			*/
			
		}
		

	});
}

$(function(){
	
	// 上传
	pagefn.upload();
	// 提交表单
	pagefn.subform();
	
});