/*
	Description : 品牌商后台管理系统 - 订单管理 - 商品列表 - 新增商品
	Author : TanShenghu
	Date : 2014-12-01
*/

var pagefn = {};

	// 文件上传
pagefn.upload = function(){
	
	var initupload = function( id ){
		$( id ).uploadify({
			height        : 75,
			width         : 75,
			'swf' : 'static/flash/uploadify.swf',
			'formData' : {},
			'uploader': '/index.json', 
			'folder': 'upload',
			'queueID': 'fileQueue',
			'auto': true,
			'buttonText':'点击上传',
			'sizeLimit':'2097152',
			'fileTypeDesc': '支持的格式：',
	        'fileTypeExts': '*.jpg;*.jpge;*.gif;*.png',
			'multi': false,
			'onFallback': function () {
	            alert("您未安装FLASH控件，无法上传图片！请安装FLASH控件后再试。");
	        },
			'onSelectError': function (file, errorCode, errorMsg){
				alert(errorMsg);
			},
	        onUploadSuccess : function(fileObj, data, response){
	        	
	        	$( '#'+data.id ).prev().empty().append( $('<img class="egPic" src="'+data.src+'">') );
	        	//$('#UploadFile').hide().after( $('<img class="egPic" src="'+data.src+'">') );

	        }
		});
	};
	
	$('.uppicbox ol li').each(function(){
		var thisObj = $(this), imglen = thisObj.find('.resultPic img').length;

		if ( imglen>0 ){
			$(this).addClass( 'exist' );
		}
		thisObj.hover(function(){
			if ( $(this).find('.resultPic img').length ){
				$(this).find('.uploadify-button-text').text('重新上传');
			}
			$(this).addClass('open');
		}, function(){
			$(this).removeClass('open');
		});;
	});
	
	var lilen = $('.uppicbox ol li').length;
	for(var i=1; i<=lilen; i++){
		initupload('#UploadFile_'+i);
	}
	
	
	
};

// 提交
pagefn.subform = function(){
	
	var box = $('.addnewshop'),
		submit = box.find('.submit');
		
	submit.on('click', function(){
		var shopTitle = $('[name="shoptitle"]'),
			shopCode = $('[name="shopcode"]'),
			Inventory = $('[name="inventory"]'),
			price = $('[name="shopprice"]'),
			content = editor.html(),
			uploadpath = $('#uploadpath');
		
		var oP = $('<p class="formTip"></p>');
		$('.formTip').remove();
		
		// 取上传图片路径
		var paths = '';
		$('.uppicbox li').each(function(){
			var img = $(this).find('.resultPic img');
			if ( img.length ){
				paths += img.attr('src')+',';
			}
		});
		paths = paths.rtrim();
		uploadpath.val( paths );
		
		if ( !shopTitle.val().trim().length ){
			shopTitle.focus().after( oP.html('请填写商品标题，限30个字符以内') );
		}else if( !shopCode.val().trim().length ){
			shopCode.focus().after( oP.html('请填写商品编码') );
		}else if( !Inventory.val().trim().length || isNaN( Inventory.val() ) ){
			var str = '请输入商品库存'
			if ( isNaN( Inventory.val() ) ){
				str = '请输入合法的商品库存！';
			}
			Inventory.focus().after( oP.html(str) );
		}else if( !price.val().trim().length || isNaN( price.val() ) ){
			var str = '请输入商品价格'
			if ( isNaN( price.val() ) ){
				str = '请输入合法的商品价格！';
			}
			price.focus().after( oP.html(str) );
		}else{
			
			var param = $.tsh.Get_form_param({form:".addnewshop"});
			param.content = content;
			// 提交至后端...
			alert( JSON.stringify(param) );
		}
		
	});
	
};

// 编辑器 
var editor;
KindEditor.ready(function(K) {
	editor = K.create('textarea[name="content"]', {
		allowFileManager : true,
		width:'780',
		height : '250'
	});
});


$(function(){
	
	// 文件上传
	pagefn.upload();
	// 表单提交
	pagefn.subform();
	
});