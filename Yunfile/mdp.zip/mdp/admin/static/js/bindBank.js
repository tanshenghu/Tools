/*
	Description : 品牌商后台管理系统 - 分销商管理
	Author : TanShenghu
	Date : 2014-12-01
*/
var pagefn = {};

pagefn.newBankPop = function(){
	
	common.popupbox({
		
		hand : ".newBankBtn",
		box : ".addNewBankPop",
		width : "400",
		height : "265"
		
	});
	
};


$(function(){
	
	// 新添加银行
	pagefn.newBankPop();
	
});