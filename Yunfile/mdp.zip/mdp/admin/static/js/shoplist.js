/*
	Description : 品牌商后台管理系统 - 订单管理 - 商品列表
	Author : TanShenghu
	Date : 2014-12-01
*/
var pagefn = {};

pagefn.checkall = function(){
	
	$.tsh.checkall('.grid .checkAll', '.grid tbody :checkbox');
	
};

$(function(){
	
	// 全选
	pagefn.checkall();
	
});