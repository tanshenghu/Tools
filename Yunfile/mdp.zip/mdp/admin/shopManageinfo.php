<?php include('public/head.php');?>
<body>
	<div class="wrap">
		<?php include('public/top.php');?>
		<!-- End userState -->
		<div class="leftBgColor"></div>
		<div id="content">
			<?php include('public/left.php');?>
			<!-- End leftMenu -->
			<div class="mainbox">
				<div class="webAdrs">
					<a href="#">首页</a> / <a href="#">二级菜单</a> / <span>三级菜单</span>
				</div>
				<h1>店铺管理</h1>
				<div class="boxblock shopCount">
					<div class="titleBox">店铺统计</div>
					<dl>
						<dd>
							<span class="blue">100</span>
							<p>日销售额(元)</p>
							<p class="wire"></p>
						</dd>
						<dd>
							<span class="blue">100</span>
							<p>日订单数量(单)</p>
							<p class="wire"></p>
						</dd>
						<dd>
							<span class="green">100</span>
							<p>月销售额(元)</p>
							<p class="wire"></p>
						</dd>
						<dd>
							<span class="green">100</span>
							<p>月订单数量(单)</p>
						</dd>
					</dl>
					<h3>类目：家纺/针织用品</h3>
				</div>	
				<div class="boxblock onlineshoplist">
					<div class="titleBox">在售商品<a href="javascript:;" class="addnew checkshopBtn">挑选商品</a></div>
					<table class="grid">
						<thead>
							<tr>
								<th width="100">ID</th>
								<th>商品名称及缩略图</th>
								<th width="120">价格</th>
								<th width="120">库存</th>
								<th width="100">状态</th>
								<th width="80">操作</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>011111</td>
								<td class="picbox"><img src="static/images/pic.jpg"><span>远梦床上四件套</span></td>
								<td>&yen;999.00</td>
								<td>9999</td>
								<td><span class="list-status1">上架</span></td>
								<td><a href="javascript:;">下架</a> <a href="share.php">分享</a></td>
							</tr>
							<tr>
								<td>011111</td>
								<td class="picbox"><img src="static/images/pic.jpg"><span>远梦床上四件套</span></td>
								<td>&yen;999.00</td>
								<td>9999</td>
								<td><span class="list-status2">下架</span></td>
								<td><a href="javascript:;">上架</a> <a href="javascript:;">分享</a></td>
							</tr>
							<tr>
								<td>011111</td>
								<td class="picbox"><img src="static/images/pic.jpg"><span>远梦床上四件套</span></td>
								<td>&yen;999.00</td>
								<td>9999</td>
								<td><span class="list-status1">上架</span></td>
								<td><a href="javascript:;">下架</a> <a href="javascript:;">分享</a></td>
							</tr>
							<tr>
								<td>011111</td>
								<td class="picbox"><img src="static/images/pic.jpg"><span>远梦床上四件套</span></td>
								<td>&yen;999.00</td>
								<td>9999</td>
								<td><span class="list-status2">下架</span></td>
								<td><a href="javascript:;">上架</a> <a href="javascript:;">分享</a></td>
							</tr>
							<tr>
								<td>011111</td>
								<td class="picbox"><img src="static/images/pic.jpg"><span>远梦床上四件套</span></td>
								<td>&yen;999.00</td>
								<td>9999</td>
								<td><span class="list-status2">下架</span></td>
								<td><a href="javascript:;">上架</a> <a href="javascript:;">分享</a></td>
							</tr>
						</tbody>
					</table>
					<div class="paging">
						<ul>
							<li class="indexpage nopage"><span>首页</span></li>
							<li class="prevpage nopage"><span>上一页</span></li>
							<li class="current"><a href="#1">1</a></li>
							<li><a href="#2">2</a></li>
							<li><a href="#3">3</a></li>
							<li><a href="#4">4</a></li>
							<li><a href="#5">5</a></li>
							<li><a href="#6">6</a></li>
							<li><a href="#7">7</a></li>
							<li><a href="#8">8</a></li>
							<li><a href="#9">9</a></li>
							<li><a href="#10">10</a></li>
							<li class="ellpage"><span>...</span></li>
							<li class="nextpage"><a href="#">下一页</a></li>
							<li class="endpage"><a href="#">尾页</a></li>
						</ul>
					</div>
				</div>
			</div>
			<!-- End mainBox -->
		</div>
		<!-- End content -->
	</div>
	<div class="popBox checkshopPop">
		<div class="titleBox">挑选商品<span class="closeMe"></span></div>
		<div class="pt10 pb5 pl20">
			搜索条件：<input type="text" class="ui-input"> <input type="button" value="搜 索" class="ui-btn1">
		</div>
		<div class="shoplist">
			<table>
				<thead>
					<tr>
						<th align="center" width="60"><a href="javascript:;" class="checkAll">全选</a></th>
						<th align="center">商品名称</th>
						<th align="right" width="120">价格</th>
						<th align="right" width="100">数量</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td align="center"><input type="checkbox"></td>
						<td align="center">
							<div class="picbox">
								<img src="static/images/pic.jpg"><span>远梦真丝四件套</span>
							</div>
						</td>
						<td align="right">&yen;999.00</td>
						<td align="right">9999</td>
					</tr>
					<tr>
						<td align="center"><input type="checkbox"></td>
						<td align="center">
						<div class="picbox">
								<img src="static/images/pic.jpg"><span>远梦真丝四件套</span>
							</div>
						</td>
						<td align="right">&yen;999.00</td>
						<td align="right">9999</td>
					</tr>
					<tr>
						<td align="center"><input type="checkbox"></td>
						<td align="center">
						<div class="picbox">
								<img src="static/images/pic.jpg"><span>远梦真丝四件套</span>
							</div>
						</td>
						<td align="right">&yen;999.00</td>
						<td align="right">9999</td>
					</tr>
					<tr>
						<td align="center"><input type="checkbox"></td>
						<td align="center">
						<div class="picbox">
								<img src="static/images/pic.jpg"><span>远梦真丝四件套</span>
							</div>
						</td>
						<td align="right">&yen;999.00</td>
						<td align="right">9999</td>
					</tr>
					<tr>
						<td align="center"><input type="checkbox"></td>
						<td align="center">
						<div class="picbox">
								<img src="static/images/pic.jpg"><span>远梦真丝四件套</span>
							</div>
						</td>
						<td align="right">&yen;999.00</td>
						<td align="right">9999</td>
					</tr>
					<tr>
						<td align="center"><input type="checkbox"></td>
						<td align="center">
						<div class="picbox">
								<img src="static/images/pic.jpg"><span>远梦真丝四件套</span>
							</div>
						</td>
						<td align="right">&yen;999.00</td>
						<td align="right">9999</td>
					</tr>
					<tr>
						<td align="center"><input type="checkbox"></td>
						<td align="center">
						<div class="picbox">
								<img src="static/images/pic.jpg"><span>远梦真丝四件套</span>
							</div>
						</td>
						<td align="right">&yen;999.00</td>
						<td align="right">9999</td>
					</tr>
					<tr>
						<td align="center"><input type="checkbox"></td>
						<td align="center">
						<div class="picbox">
								<img src="static/images/pic.jpg"><span>远梦真丝四件套</span>
							</div>
						</td>
						<td align="right">&yen;999.00</td>
						<td align="right">9999</td>
					</tr>
					<tr>
						<td align="center"><input type="checkbox"></td>
						<td align="center">
						<div class="picbox">
								<img src="static/images/pic.jpg"><span>远梦真丝四件套</span>
							</div>
						</td>
						<td align="right">&yen;999.00</td>
						<td align="right">9999</td>
					</tr>
					<tr>
						<td align="center"><input type="checkbox"></td>
						<td align="center">
						<div class="picbox">
								<img src="static/images/pic.jpg"><span>远梦真丝四件套</span>
							</div>
						</td>
						<td align="right">&yen;999.00</td>
						<td align="right">9999</td>
					</tr>
					<tr>
						<td align="center"><input type="checkbox"></td>
						<td align="center">
						<div class="picbox">
								<img src="static/images/pic.jpg"><span>远梦真丝四件套</span>
							</div>
						</td>
						<td align="right">&yen;999.00</td>
						<td align="right">9999</td>
					</tr>
					<tr>
						<td align="center"><input type="checkbox"></td>
						<td align="center">
						<div class="picbox">
								<img src="static/images/pic.jpg"><span>远梦真丝四件套</span>
							</div>
						</td>
						<td align="right">&yen;999.00</td>
						<td align="right">9999</td>
					</tr>
					<tr>
						<td align="center"><input type="checkbox"></td>
						<td align="center">
						<div class="picbox">
								<img src="static/images/pic.jpg"><span>远梦真丝四件套</span>
							</div>
						</td>
						<td align="right">&yen;999.00</td>
						<td align="right">9999</td>
					</tr>
				</tbody>
			</table>
			<p align="center" class="pt20 pb10"><input type="button" class="ui-btn1" value="确 定"></p>
		</div>
	</div>
	<script src="static/js/shopManageinfo.js"></script>
</body>
</html>